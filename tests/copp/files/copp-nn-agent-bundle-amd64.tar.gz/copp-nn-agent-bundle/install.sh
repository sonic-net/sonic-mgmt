#!/bin/bash
set -euo pipefail

bundle_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
architecture="$(dpkg --print-architecture)"
python_abi="cp$(python3 -c 'import sys; print(f"{sys.version_info.major}{sys.version_info.minor}")')"

if [[ "$architecture" != "amd64" ]]; then
    echo "Unsupported syncd architecture for CoPP NN agent bundle: $architecture" >&2
    exit 1
fi
if [[ ! -d "$bundle_dir/python/$python_abi" ]]; then
    echo "Unsupported syncd Python ABI for CoPP NN agent bundle: $python_abi" >&2
    exit 1
fi

if ! ldconfig -p | grep -q 'libnanomsg\.so\.5'; then
    dpkg -i "$bundle_dir"/lib/libnanomsg5_*_amd64.deb
    ldconfig
fi

site_dir="$(python3 -c 'import site; print(site.getsitepackages()[0])')"
cp -a "$bundle_dir/python/common/." "$site_dir/"
cp -a "$bundle_dir/python/$python_abi/." "$site_dir/"
install -d -m 0755 /opt/ptf
install -m 0644 "$bundle_dir/ptf_nn_agent.py" /opt/ptf_nn_agent.py
install -m 0644 "$bundle_dir/ptf/__init__.py" "$bundle_dir/ptf/afpacket.py" /opt/ptf/

python3 - <<'PY'
import nnpy
sock = nnpy.Socket(nnpy.AF_SP, nnpy.PAIR)
PY
python3 /opt/ptf_nn_agent.py --help >/dev/null
