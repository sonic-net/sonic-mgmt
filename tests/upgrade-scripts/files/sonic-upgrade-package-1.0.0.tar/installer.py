import os
import sys
import subprocess
import argparse

PY2_WHEEL = "sonic_critical_process_checker-1.0.0-py2-none-any.whl"
PY3_WHEEL = "sonic_critical_process_checker-1.0.0-py3-none-any.whl"
PACKAGE_NAME = "sonic_critical_process_checker"
INSTALLER = "installer.py"
TAR_FILE = "sonic-upgrade-package-1.0.0.tar"

def get_sonic_version_info():
    SONIC_VERSION_YAML_PATH = "/etc/sonic/sonic_version.yml"
    if not os.path.isfile(SONIC_VERSION_YAML_PATH):
        return None

    sonic_ver_info = {}
    if sonic_ver_info:
        return sonic_ver_info

    try:
        with open(SONIC_VERSION_YAML_PATH, 'r') as stream:
            for line in stream:
                if 'build_version' in line:
                    sonic_ver_info['build_version'] = line.split(':')[1].strip()
                    break
    except Exception as e:
        sonic_ver_info['build_version'] = ""
        return sonic_ver_info

    return sonic_ver_info


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--install", action="store_true", help="Install the package.")
    parser.add_argument("--uninstall", action="store_true", help="Uninstall the package.")
    parser.add_argument("--validate", action="store_true", help="Validate all tar files are present in current directory.")
    args = parser.parse_args()

    if not args.install and not args.uninstall and not args.validate:
        sys.exit(1)

    os_version = get_sonic_version_info()['build_version']
    script_path = os.path.dirname(os.path.abspath(__file__))
    py2_wheel_path = os.path.join(script_path, PY2_WHEEL)
    py3_wheel_path = os.path.join(script_path, PY3_WHEEL)
    tar_file_path = os.path.join(script_path, TAR_FILE)

    if args.uninstall:
        try:
            subprocess.check_call(["sudo", "pip", "--disable-pip-version-check", "uninstall", PACKAGE_NAME, "-y"])
            if os.path.exists(os.path.join(script_path, PY2_WHEEL)):
                subprocess.check_call(["sudo", "rm", os.path.join(script_path, PY2_WHEEL)])
            if os.path.exists(os.path.join(script_path, PY3_WHEEL)):
                subprocess.check_call(["sudo", "rm", os.path.join(script_path, PY3_WHEEL)])
            if os.path.exists(os.path.join(script_path, INSTALLER)):
                subprocess.check_call(["sudo", "rm", os.path.join(script_path, INSTALLER)])
            if os.path.exists(os.path.join(script_path, TAR_FILE)):
                subprocess.check_call(["sudo", "rm", os.path.join(script_path, TAR_FILE)])
            sys.exit(0)
        except Exception as e:
            print("Uninstalling package failed with error: {}".format(e))
            sys.exit(1)

    if args.install:
        try:
            if "201811" in os_version or "201911" in os_version:
                subprocess.check_call(["sudo", "pip", "--disable-pip-version-check", "install", py2_wheel_path])
            else:
                subprocess.check_call(["sudo", "pip", "--disable-pip-version-check", "install", py3_wheel_path])
            sys.exit(0)
        except Exception as e:
            print("Installing package failed with error: {}".format(e))
            sys.exit(1)

    if args.validate:
        try:
            command = "pip show {} > /dev/null 2>&1".format(PACKAGE_NAME)
            returncode = subprocess.call(command, shell=True)
            if returncode == 0:
                print("Package {} is installed".format(PACKAGE_NAME))
            else:
                print("Package {} is not installed".format(PACKAGE_NAME))
            sys.exit(0)
        except Exception as e:
            print("Validating package failed with error: {}".format(e))
            sys.exit(1)


if __name__ == "__main__":
    main()
