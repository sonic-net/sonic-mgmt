"""Stage 1c acceptance: one flow through a real DUT.

See docs/phase1c-dut.md for cabling, /31 addressing, and static neighbours on
the DUT.
"""

import argparse
import os
import sys
import time

import snappi

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b2b_flow import bypass_proxy, wait_until_stopped  # noqa: E402
from otg_metrics import poll_flow_metric, poll_port_metrics  # noqa: E402

DEFAULT_API = os.environ.get("TGEN_API", "http://172.17.0.1:8443")
DEFAULT_TX = os.environ.get("TGEN_TX_LOCATION", "Card1/Port1")
DEFAULT_RX = os.environ.get("TGEN_RX_LOCATION", "Card1/Port2")


def build_config(
    api,
    tx_location,
    rx_location,
    frame_size,
    rate_pps,
    seconds,
    src_mac,
    dst_mac,
    src_ip,
    dst_ip,
    src_port,
    dst_port,
):
    config = api.config()

    tx = config.ports.port(name="tx", location=tx_location)[-1]
    rx = config.ports.port(name="rx", location=rx_location)[-1]

    flow = config.flows.flow(name="dut")[-1]
    flow.tx_rx.port.tx_name = tx.name
    flow.tx_rx.port.rx_names = [rx.name]
    flow.size.fixed = frame_size
    flow.duration.fixed_seconds.seconds = seconds
    flow.metrics.enable = True

    if rate_pps:
        flow.rate.pps = rate_pps
    else:
        flow.rate.percentage = 100

    eth, ipv4, udp = flow.packet.ethernet().ipv4().udp()
    eth.src.value = src_mac
    eth.dst.value = dst_mac
    ipv4.src.value = src_ip
    ipv4.dst.value = dst_ip
    udp.src_port.value = src_port
    udp.dst_port.value = dst_port

    return config


def _port_by_name(port_metrics, name):
    for port in port_metrics:
        if port.name == name:
            return port
    return None


def reconcile_1c(
    flow,
    port_metrics,
    dut_ingress_rx,
    dut_egress_tx,
    tolerance,
):
    """Return (ok, list of (check_name, passed, detail))."""
    tx_port = _port_by_name(port_metrics, "tx")
    rx_port = _port_by_name(port_metrics, "rx")
    checks = []

    lost = flow.frames_tx - flow.frames_rx
    checks.append(
        (
            "generator flow tx equals rx",
            lost == 0,
            "tx=%d rx=%d lost=%d" % (flow.frames_tx, flow.frames_rx, lost),
        )
    )
    checks.append(
        (
            "generator transmitted frames",
            flow.frames_tx > 0,
            "frames_tx=%d" % flow.frames_tx,
        )
    )

    if tx_port is not None:
        checks.append(
            (
                "flow tx equals tx port hardware opackets",
                flow.frames_tx == tx_port.frames_tx,
                "flow=%d hw=%d" % (flow.frames_tx, tx_port.frames_tx),
            )
        )
    if rx_port is not None:
        checks.append(
            (
                "flow rx equals rx port hardware ipackets",
                flow.frames_rx <= rx_port.frames_rx,
                "flow=%d hw=%d" % (flow.frames_rx, rx_port.frames_rx),
            )
        )

    if dut_ingress_rx is not None:
        delta = abs(flow.frames_tx - dut_ingress_rx)
        checks.append(
            (
                "DUT ingress RX matches generator tx",
                delta <= tolerance,
                "tgen_tx=%d dut_rx=%d delta=%d tol=%d"
                % (flow.frames_tx, dut_ingress_rx, delta, tolerance),
            )
        )
    if dut_egress_tx is not None:
        delta = abs(flow.frames_rx - dut_egress_tx)
        checks.append(
            (
                "DUT egress TX matches generator rx",
                delta <= tolerance,
                "tgen_rx=%d dut_tx=%d delta=%d tol=%d"
                % (flow.frames_rx, dut_egress_tx, delta, tolerance),
            )
        )

    ok = all(passed for _, passed, _ in checks)
    return ok, checks


def run(
    api_location,
    tx_location,
    rx_location,
    frame_size,
    rate_pps,
    seconds,
    src_mac,
    dst_mac,
    src_ip,
    dst_ip,
    src_port,
    dst_port,
    dut_ingress_rx,
    dut_egress_tx,
    counter_tolerance,
    require_dut_counters,
):
    bypass_proxy(api_location)
    api = snappi.api(location=api_location, verify=False)

    print("DUT flow: %s -> %s" % (tx_location, rx_location))
    print("  L2 %s -> %s" % (src_mac, dst_mac))
    print(
        "  L3 %s -> %s  UDP %d -> %d" % (src_ip, dst_ip, src_port, dst_port)
    )

    config = build_config(
        api,
        tx_location,
        rx_location,
        frame_size,
        rate_pps,
        seconds,
        src_mac,
        dst_mac,
        src_ip,
        dst_ip,
        src_port,
        dst_port,
    )
    response = api.set_config(config)
    for warning in getattr(response, "warnings", None) or []:
        print("  warning: %s" % warning)

    print("starting traffic for %ds" % seconds)
    state = api.control_state()
    state.traffic.flow_transmit.state = state.traffic.flow_transmit.START
    api.set_control_state(state)

    wait_until_stopped(api_location, "dut", timeout=seconds + 30)
    time.sleep(1)

    flow = poll_flow_metric(api_location, "dut")
    ports = poll_port_metrics(api_location, ["tx", "rx"])

    wire_gbps = flow.frames_tx * (frame_size + 24) * 8.0 / seconds / 1e9
    print("\n=== generator ===")
    print(
        "frames_tx %d  frames_rx %d  lost %d"
        % (flow.frames_tx, flow.frames_rx, flow.frames_tx - flow.frames_rx)
    )
    print("bytes_tx  %d  bytes_rx  %d" % (flow.bytes_tx, flow.bytes_rx))
    print("average   %.2f Gbps on the wire over %ds" % (wire_gbps, seconds))
    for port in ports:
        print(
            "port %-3s (%s)  hw tx %d  hw rx %d"
            % (port.name, port.location, port.frames_tx, port.frames_rx)
        )

    if dut_ingress_rx is None and dut_egress_tx is None:
        print(
            "\nDUT counters not supplied. After the run, collect ingress RX on "
            "the transmit link and egress TX on the receive link, then re-run "
            "with --dut-ingress-rx and --dut-egress-tx (see docs/phase1c-dut.md)."
        )
    else:
        print("\n=== DUT (operator supplied) ===")
        if dut_ingress_rx is not None:
            print("ingress RX (toward generator tx link): %d" % dut_ingress_rx)
        if dut_egress_tx is not None:
            print("egress TX (toward generator rx link):  %d" % dut_egress_tx)

    if require_dut_counters and (
        dut_ingress_rx is None or dut_egress_tx is None
    ):
        raise AssertionError(
            "--require-dut-counters set but --dut-ingress-rx / "
            "--dut-egress-tx not both provided"
        )

    ok, checks = reconcile_1c(
        flow,
        ports,
        dut_ingress_rx,
        dut_egress_tx,
        counter_tolerance,
    )

    print("\n=== checks ===")
    for name, passed, detail in checks:
        print("  [%s] %s — %s" % ("PASS" if passed else "FAIL", name, detail))

    if not ok:
        raise AssertionError("one or more 1c checks failed")

    if dut_ingress_rx is not None and dut_egress_tx is not None:
        print("\n1c ACCEPTANCE: PASS (generator and DUT counters)")
    else:
        print("\n1c ACCEPTANCE: PASS (generator path; add DUT counters for full sign-off)")


def main(argv=None):
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--api", default=DEFAULT_API)
    parser.add_argument("--tx-location", default=DEFAULT_TX)
    parser.add_argument("--rx-location", default=DEFAULT_RX)
    parser.add_argument("--frame-size", type=int, default=9000)
    parser.add_argument("--rate-pps", type=int, default=200000, help="0 for line rate")
    parser.add_argument("--seconds", type=int, default=10)
    parser.add_argument("--src-mac", required=True)
    parser.add_argument("--dst-mac", required=True, help="DUT MAC on the transmit link")
    parser.add_argument("--src-ip", required=True)
    parser.add_argument("--dst-ip", required=True)
    parser.add_argument("--src-port", type=int, default=5001)
    parser.add_argument("--dst-port", type=int, default=5002)
    parser.add_argument(
        "--dut-ingress-rx",
        type=int,
        default=None,
        help="DUT RX packet count on the port cabled to generator tx",
    )
    parser.add_argument(
        "--dut-egress-tx",
        type=int,
        default=None,
        help="DUT TX packet count on the port cabled to generator rx",
    )
    parser.add_argument(
        "--counter-tolerance",
        type=int,
        default=0,
        help="allowed |tgen - dut| packet difference for DUT checks",
    )
    parser.add_argument(
        "--require-dut-counters",
        action="store_true",
        help="fail if DUT counter arguments are not supplied",
    )
    args = parser.parse_args(argv)

    try:
        run(
            args.api,
            args.tx_location,
            args.rx_location,
            args.frame_size,
            args.rate_pps,
            args.seconds,
            args.src_mac,
            args.dst_mac,
            args.src_ip,
            args.dst_ip,
            args.src_port,
            args.dst_port,
            args.dut_ingress_rx,
            args.dut_egress_tx,
            args.counter_tolerance,
            args.require_dut_counters,
        )
    except AssertionError as exc:
        print("\n1c ACCEPTANCE: FAIL (%s)" % exc)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
