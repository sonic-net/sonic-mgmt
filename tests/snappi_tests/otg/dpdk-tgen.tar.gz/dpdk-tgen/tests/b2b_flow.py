"""Stage 1b acceptance: drive the generator with snappi over the OTG API.

With the two ports cabled back to back, configure one UDP flow, run it for a
fixed time, and require that every frame transmitted was received.

Run it directly:

    python3 tests/b2b_flow.py --api http://100.117.29.53:8443

or under pytest, where the same options are read from the environment:

    TGEN_API=http://100.117.29.53:8443 pytest tests/b2b_flow.py
"""

import argparse
import os
import sys
import time
from urllib.parse import urlparse

import snappi

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from otg_metrics import poll_flow_metric  # noqa: E402

DEFAULT_API = os.environ.get("TGEN_API", "http://127.0.0.1:8443")
DEFAULT_TX = os.environ.get("TGEN_TX_LOCATION", "Card1/Port1")
DEFAULT_RX = os.environ.get("TGEN_RX_LOCATION", "Card1/Port2")


def build_config(api, tx_location, rx_location, frame_size, rate_pps, seconds):
    config = api.config()

    tx = config.ports.port(name="tx", location=tx_location)[-1]
    rx = config.ports.port(name="rx", location=rx_location)[-1]

    flow = config.flows.flow(name="b2b")[-1]
    flow.tx_rx.port.tx_name = tx.name
    flow.tx_rx.port.rx_names = [rx.name]
    flow.size.fixed = frame_size
    flow.duration.fixed_seconds.seconds = seconds
    flow.metrics.enable = True

    if rate_pps:
        flow.rate.pps = rate_pps
    else:
        flow.rate.percentage = 100

    # The engine defaults the MAC addresses to the two ports' own hardware
    # addresses, which is what back-to-back cabling needs, so only the IPv4
    # and UDP fields are worth setting here.
    _, ipv4, udp = flow.packet.ethernet().ipv4().udp()
    ipv4.src.value = "10.0.0.1"
    ipv4.dst.value = "10.0.0.2"
    udp.src_port.value = 5001
    udp.dst_port.value = 5002

    return config


def wait_until_stopped(api_location, flow_name, timeout):
    """Poll metrics until the engine reports transmit has finished."""
    deadline = time.time() + timeout
    metric = None
    while time.time() < deadline:
        metric = poll_flow_metric(api_location, flow_name)
        print(
            "  tx %12d  rx %12d  tx_rate %10.0f pps  rx_rate %10.0f pps  %s"
            % (
                metric.frames_tx,
                metric.frames_rx,
                metric.frames_tx_rate,
                metric.frames_rx_rate,
                metric.transmit,
            )
        )
        if metric.transmit == "stopped" and metric.frames_tx > 0:
            return metric
        time.sleep(1)

    raise AssertionError("transmit did not stop within %ds" % timeout)


def bypass_proxy(api_location):
    """Keep the API request off any configured HTTP proxy.

    snappi talks over ``requests``, which sends every URL not listed in
    ``no_proxy`` to the proxy named in the environment. On a lab machine with
    a corporate proxy configured that includes the generator's own address,
    so the request leaves the box, fails, and leaks the configuration to the
    proxy's logs on the way.
    """
    host = urlparse(api_location).hostname
    if not host:
        return
    for name in ("no_proxy", "NO_PROXY"):
        current = os.environ.get(name, "")
        if host not in current.split(","):
            os.environ[name] = ",".join(filter(None, [current, host]))


def run(api_location, tx_location, rx_location, frame_size, rate_pps, seconds):
    bypass_proxy(api_location)
    api = snappi.api(location=api_location, verify=False)
    # api_location reused for metrics polling (see otg_metrics.py).

    print("configuring %s -> %s" % (tx_location, rx_location))
    config = build_config(api, tx_location, rx_location, frame_size, rate_pps, seconds)
    response = api.set_config(config)
    for warning in getattr(response, "warnings", None) or []:
        print("  warning: %s" % warning)

    print("starting traffic for %ds" % seconds)
    state = api.control_state()
    state.traffic.flow_transmit.state = state.traffic.flow_transmit.START
    api.set_control_state(state)

    metric = wait_until_stopped(api_location, "b2b", timeout=seconds + 30)

    # Counters settle a moment after transmit stops, so take the final
    # reading once the last frames have been attributed.
    time.sleep(1)
    metric = poll_flow_metric(api_location, "b2b")

    lost = metric.frames_tx - metric.frames_rx
    wire_gbps = metric.frames_tx * (frame_size + 24) * 8.0 / seconds / 1e9

    print("\nframes_tx %d  frames_rx %d  lost %d" % (metric.frames_tx, metric.frames_rx, lost))
    print("bytes_tx  %d  bytes_rx  %d" % (metric.bytes_tx, metric.bytes_rx))
    print("average   %.2f Gbps on the wire over %ds" % (wire_gbps, seconds))

    assert metric.frames_tx > 0, "nothing was transmitted"
    assert lost == 0, "%d frames lost back to back" % lost
    assert metric.bytes_tx == metric.bytes_rx, "byte counts disagree"
    print("\n1b ACCEPTANCE: PASS")


def test_back_to_back():
    run(DEFAULT_API, DEFAULT_TX, DEFAULT_RX, 9000, 200000, 10)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--api", default=DEFAULT_API)
    parser.add_argument("--tx-location", default=DEFAULT_TX)
    parser.add_argument("--rx-location", default=DEFAULT_RX)
    parser.add_argument("--frame-size", type=int, default=9000)
    parser.add_argument(
        "--rate-pps", type=int, default=200000, help="0 for line rate"
    )
    parser.add_argument("--seconds", type=int, default=10)
    args = parser.parse_args(argv)

    try:
        run(
            args.api,
            args.tx_location,
            args.rx_location,
            args.frame_size,
            args.rate_pps,
            args.seconds,
        )
    except AssertionError as exc:
        print("\n1b ACCEPTANCE: FAIL (%s)" % exc)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
