"""Control process for the dpdk-tgen traffic generator.

Layout:
    resources  the machine and hardware facts, loaded from a JSON template
    engine     supervision of, and the command channel to, the C++ data plane
    shm        reader for the shared-memory counter region
    otg        translation from an OTG configuration to engine flows
    server     the OTG REST subset snappi clients talk to
"""

__version__ = "0.1.0"
