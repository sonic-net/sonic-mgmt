"""Reader for the shared-memory statistics region written by the engine.

The layout mirrors ``src/tgen.hpp``. Both sides carry compile-time assertions
on the same numbers, so a mismatch shows up immediately rather than as
plausible-looking garbage counters.
"""

import mmap
import os
import struct

MAGIC = 0x5447534D  # "TGSM"
LAYOUT_VERSION = 1

MAX_FLOWS = 16
MAX_PORTS = 8
MAX_LCORES = 128

# struct ShmHeader
_HEADER = struct.Struct(
    "<"
    "I"  # magic
    "I"  # layout_version
    "I"  # nb_lcores
    "I"  # nb_flows
    "I"  # nb_ports
    "I"  # engine_state
    "Q"  # tsc_hz
    "Q"  # start_tsc
)

# struct PortHwCounters
_PORT = struct.Struct("<8Q")

# struct FlowCounters
_FLOW = struct.Struct("<5Q")

PORT_OFFSET = 40
LCORE_OFFSET = 576  # LcoreBlock is cache aligned, so this is not 40 + 8 * 64
LCORE_STRIDE = 704  # sizeof(LcoreBlock), also cache aligned
REGION_SIZE = LCORE_OFFSET + MAX_LCORES * LCORE_STRIDE

assert _HEADER.size == PORT_OFFSET
assert _FLOW.size * MAX_FLOWS + 16 <= LCORE_STRIDE

STATE_INIT = 0
STATE_READY = 1
STATE_RUNNING = 2
STATE_STOPPING = 3
STATE_ERROR = 4

STATE_NAMES = {
    STATE_INIT: "init",
    STATE_READY: "ready",
    STATE_RUNNING: "running",
    STATE_STOPPING: "stopping",
    STATE_ERROR: "error",
}


class FlowStats(object):
    __slots__ = ("tx_pkts", "tx_bytes", "tx_fail", "rx_pkts", "rx_bytes")

    def __init__(self):
        self.tx_pkts = 0
        self.tx_bytes = 0
        self.tx_fail = 0
        self.rx_pkts = 0
        self.rx_bytes = 0

    @property
    def loss(self):
        return self.tx_pkts - self.rx_pkts

    def as_dict(self):
        return {name: getattr(self, name) for name in self.__slots__}


class PortStats(object):
    __slots__ = (
        "opackets",
        "obytes",
        "ipackets",
        "ibytes",
        "imissed",
        "ierrors",
        "oerrors",
        "rx_nombuf",
    )

    def __init__(self, values=None):
        for name, value in zip(self.__slots__, values or [0] * 8):
            setattr(self, name, value)

    def as_dict(self):
        return {name: getattr(self, name) for name in self.__slots__}


class StatsReader(object):
    """Maps the region read-only and sums the per-lcore counter blocks.

    Counters are plain 64-bit stores from a single writer per lcore, so a read
    can tear across the pair of words in a flow entry. At the rates we run,
    a torn read is at worst one sample off, and callers only compare totals
    after transmit has stopped.
    """

    def __init__(self, path="/dev/shm/dpdk-tgen-stats"):
        self.path = path
        self._fd = os.open(path, os.O_RDONLY)
        size = os.fstat(self._fd).st_size
        if size < REGION_SIZE:
            os.close(self._fd)
            raise ValueError(
                "%s is %d bytes, expected at least %d" % (path, size, REGION_SIZE)
            )
        self._map = mmap.mmap(self._fd, REGION_SIZE, prot=mmap.PROT_READ)

        magic, version = struct.unpack_from("<II", self._map, 0)
        if magic != MAGIC:
            self.close()
            raise ValueError("%s: bad magic 0x%08x" % (path, magic))
        if version != LAYOUT_VERSION:
            self.close()
            raise ValueError(
                "%s: layout version %d, this reader speaks %d"
                % (path, version, LAYOUT_VERSION)
            )

    def close(self):
        if getattr(self, "_map", None) is not None:
            self._map.close()
            self._map = None
        if getattr(self, "_fd", None) is not None:
            os.close(self._fd)
            self._fd = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def header(self):
        fields = _HEADER.unpack_from(self._map, 0)
        return {
            "magic": fields[0],
            "layout_version": fields[1],
            "nb_lcores": fields[2],
            "nb_flows": fields[3],
            "nb_ports": fields[4],
            "engine_state": fields[5],
            "state": STATE_NAMES.get(fields[5], "unknown"),
            "tsc_hz": fields[6],
            "start_tsc": fields[7],
        }

    def port(self, port_id):
        if port_id >= MAX_PORTS:
            raise IndexError("port %d out of range" % port_id)
        offset = PORT_OFFSET + port_id * _PORT.size
        return PortStats(_PORT.unpack_from(self._map, offset))

    def flow(self, flow_id):
        """Sum one flow's counters across every lcore block."""
        if flow_id >= MAX_FLOWS:
            raise IndexError("flow %d out of range" % flow_id)

        total = FlowStats()
        for lcore in range(MAX_LCORES):
            offset = LCORE_OFFSET + lcore * LCORE_STRIDE + flow_id * _FLOW.size
            tx_pkts, tx_bytes, tx_fail, rx_pkts, rx_bytes = _FLOW.unpack_from(
                self._map, offset
            )
            total.tx_pkts += tx_pkts
            total.tx_bytes += tx_bytes
            total.tx_fail += tx_fail
            total.rx_pkts += rx_pkts
            total.rx_bytes += rx_bytes
        return total

    def diagnostics(self):
        """Counters that indicate the engine is not keeping up."""
        rx_unmatched = 0
        tx_alloc_fail = 0
        for lcore in range(MAX_LCORES):
            base = LCORE_OFFSET + lcore * LCORE_STRIDE + MAX_FLOWS * _FLOW.size
            unmatched, alloc_fail = struct.unpack_from("<2Q", self._map, base)
            rx_unmatched += unmatched
            tx_alloc_fail += alloc_fail
        return {"rx_unmatched": rx_unmatched, "tx_alloc_fail": tx_alloc_fail}
