"""The OTG REST subset that snappi clients talk to.

Only the handful of endpoints phase 1 needs are implemented. Everything is
standard library, so the container needs no Python packages at all.
"""

import argparse
import json
import logging
import os
import re
import signal
import ssl
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import otg, preflight
from .engine import CommandClient, EngineError, EngineProcess
from .resources import Resources
from .shm import STATE_RUNNING, StatsReader

LOG = logging.getLogger("dpdk-tgen")

API_SPEC_VERSION = "1.14.0"  # the OTG version this subset is written against
APP_VERSION = "0.1.0"

# snappi validates these as Python float after JSON decode; whole numbers in
# JSON become int unless the text carries a fraction.
_SNAPPI_FLOAT_FIELDS = (
    "loss",
    "frames_tx_rate",
    "frames_rx_rate",
    "bytes_tx_rate",
    "bytes_rx_rate",
)


def _otg_float(value):
    return float(value)


def _coerce_snappi_floats(obj):
    if isinstance(obj, dict):
        for key, value in list(obj.items()):
            if key in _SNAPPI_FLOAT_FIELDS and isinstance(value, (int, float)):
                obj[key] = float(value)
            else:
                _coerce_snappi_floats(value)
    elif isinstance(obj, list):
        for item in obj:
            _coerce_snappi_floats(item)


def _json_dumps_snappi_safe(payload):
    _coerce_snappi_floats(payload)
    text = json.dumps(payload, separators=(",", ":"))
    # json may still emit bare integers for float(0.0); snappi rejects those.
    for key in _SNAPPI_FLOAT_FIELDS:
        text = re.sub(
            r'"%s":(-?\d+)([,}\]])' % key,
            r'"%s":\1.0\2' % key,
            text,
        )
    return text


class ApiError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


class TgenApi(object):
    """Holds the engine, the current configuration and the last metrics sample."""

    def __init__(self, resources, engine_log=None, own_engine=True):
        self.resources = resources
        self.own_engine = own_engine
        self.process = EngineProcess(resources, log_path=engine_log) if own_engine else None
        self.stats = None
        self.config = None  # a TranslatedConfig
        self._sample = None  # (monotonic time, {flow_id: (tx_pkts, rx_pkts, tx_bytes, rx_bytes)})

    def start(self):
        if self.process is not None:
            self.process.start()
        self.stats = StatsReader(self.resources.shm_path)

    def stop(self):
        if self.stats is not None:
            self.stats.close()
            self.stats = None
        if self.process is not None:
            self.process.stop()

    def _command(self):
        return CommandClient(self.resources.socket_path).connect(retries=3)

    def _check_warnings(self, warnings):
        if warnings and self.resources.strict_unsupported:
            raise ApiError(
                "configuration uses unsupported settings and strict_unsupported "
                "is set: " + "; ".join(warnings)
            )
        for warning in warnings:
            LOG.warning("%s", warning)

    # Endpoint implementations.

    def get_version(self):
        return {
            "api_spec_version": API_SPEC_VERSION,
            "sdk_version": APP_VERSION,
            "app_version": APP_VERSION,
        }

    def set_config(self, config):
        try:
            translated = otg.translate(config, self.resources)
        except otg.ConfigError as exc:
            raise ApiError(str(exc))

        self._check_warnings(translated.warnings)

        # Nothing reaches the engine until every flow is known to be confined
        # to the link it leaves on.
        for flow in translated.flows:
            try:
                preflight.check_flow(flow, self.resources)
            except preflight.SafetyError as exc:
                raise ApiError(str(exc))

        with self._command() as cmd:
            cmd.send("STOP")
            cmd.send("RESET")
            for flow in translated.flows:
                cmd.send("CONFIGURE", **flow.command_kwargs())

        self.config = translated
        self._sample = None
        LOG.info(
            "configured %d flow(s): %s",
            len(translated.flows),
            ", ".join(
                "%s %d bytes @ %s pps" % (f.name, f.frame_size, f.rate_pps or "line")
                for f in translated.flows
            ),
        )
        return {"warnings": translated.warnings}

    def get_config(self):
        if self.config is None:
            raise ApiError("no configuration has been set", status=404)
        return self.config.raw

    def set_control_state(self, request):
        if self.config is None:
            raise ApiError("no configuration has been set")

        warnings = []
        choice = request.get("choice")

        if choice != "traffic":
            raise ApiError(
                "only traffic control is supported in phase 1, got %r" % choice
            )

        traffic = request.get("traffic") or {}
        if traffic.get("choice") != "flow_transmit":
            raise ApiError(
                "only traffic.flow_transmit is supported, got %r"
                % traffic.get("choice")
            )

        transmit = traffic.get("flow_transmit") or {}
        state = transmit.get("state")
        names = transmit.get("flow_names") or []

        if names and len(names) != len(self.config.flows):
            warnings.append(
                "flow_names is ignored; start and stop apply to every "
                "configured flow in phase 1"
            )

        with self._command() as cmd:
            if state == "start":
                cmd.send("START")
            elif state == "stop":
                cmd.send("STOP")
            elif state in ("pause", "resume"):
                raise ApiError("%r is not supported in phase 1" % state)
            else:
                raise ApiError("unknown transmit state %r" % state)

        self._sample = None
        LOG.info("traffic %s", state)
        return {"warnings": warnings}

    def set_control_action(self, request):
        raise ApiError("control actions are not supported in phase 1")

    def get_metrics(self, request):
        if self.stats is None:
            raise ApiError("engine is not running", status=503)

        choice = request.get("choice") or ("flow" if "flow" in request else "port")
        # The request names the metric group "flow"; the response names it
        # "flow_metrics". They are not the same enum.
        if choice == "flow":
            return {
                "choice": "flow_metrics",
                "flow_metrics": self._flow_metrics(request),
            }
        if choice == "port":
            return {
                "choice": "port_metrics",
                "port_metrics": self._port_metrics(request),
            }
        raise ApiError("metrics for %r are not supported in phase 1" % choice)

    def _rates(self, current):
        """Per-second rates from the difference against the previous poll."""
        now = time.monotonic()
        previous = self._sample
        self._sample = (now, current)
        if previous is None:
            return {}

        elapsed = now - previous[0]
        if elapsed <= 0:
            return {}

        rates = {}
        for flow_id, values in current.items():
            before = previous[1].get(flow_id)
            if before is None:
                continue
            rates[flow_id] = tuple(
                (after - old) / elapsed for after, old in zip(values, before)
            )
        return rates

    def _flow_metrics(self, request):
        wanted = (request.get("flow") or {}).get("flow_names") or []
        header = self.stats.header()
        running = header["engine_state"] == STATE_RUNNING

        current = {}
        for flow in self.config.flows:
            totals = self.stats.flow(flow.flow_id)
            current[flow.flow_id] = (
                totals.tx_pkts,
                totals.rx_pkts,
                totals.tx_bytes,
                totals.rx_bytes,
            )
        rates = self._rates(current)

        metrics = []
        for flow in self.config.flows:
            if wanted and flow.name not in wanted:
                continue
            tx_pkts, rx_pkts, tx_bytes, rx_bytes = current[flow.flow_id]
            rate = rates.get(flow.flow_id, (0.0, 0.0, 0.0, 0.0))
            lost = tx_pkts - rx_pkts
            metrics.append(
                {
                    "name": flow.name,
                    "transmit": "started" if running else "stopped",
                    "frames_tx": tx_pkts,
                    "frames_rx": rx_pkts,
                    "bytes_tx": tx_bytes,
                    "bytes_rx": rx_bytes,
                    "frames_tx_rate": _otg_float(round(rate[0], 3)),
                    "frames_rx_rate": _otg_float(round(rate[1], 3)),
                    "bytes_tx_rate": _otg_float(round(rate[2], 3)),
                    "bytes_rx_rate": _otg_float(round(rate[3], 3)),
                    "loss": _otg_float(
                        round(100.0 * lost / tx_pkts, 6) if tx_pkts else 0.0
                    ),
                }
            )
        return metrics

    def _port_metrics(self, request):
        wanted = (request.get("port") or {}).get("port_names") or []
        metrics = []
        for name, port in self.config.ports:
            if wanted and name not in wanted:
                continue
            hw = self.stats.port(port.index)
            metrics.append(
                {
                    "name": name,
                    "location": port.location,
                    "link": "up",
                    "capture": "stopped",
                    "frames_tx": hw.opackets,
                    "frames_rx": hw.ipackets,
                    "bytes_tx": hw.obytes,
                    "bytes_rx": hw.ibytes,
                    "frames_tx_rate": 0.0,
                    "frames_rx_rate": 0.0,
                }
            )
        return metrics


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "dpdk-tgen/" + APP_VERSION

    @property
    def api(self):
        return self.server.api

    def log_message(self, fmt, *args):
        LOG.debug("%s %s", self.address_string(), fmt % args)

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError as exc:
            raise ApiError("request body is not valid JSON: %s" % exc)

    def _reply(self, status, payload):
        body = _json_dumps_snappi_safe(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _dispatch(self, routes):
        handler = routes.get(self.path.split("?")[0])
        if handler is None:
            self._reply(404, {"status_code": 404, "errors": ["no such endpoint"]})
            return
        try:
            self._reply(200, handler())
        except ApiError as exc:
            LOG.warning("%s %s: %s", self.command, self.path, exc)
            self._reply(exc.status, {"status_code": exc.status, "errors": [str(exc)]})
        except EngineError as exc:
            LOG.error("engine: %s", exc)
            self._reply(500, {"status_code": 500, "errors": ["engine: %s" % exc]})
        except Exception as exc:  # noqa: BLE001 - the client deserves the reason
            LOG.exception("unhandled error")
            self._reply(500, {"status_code": 500, "errors": [repr(exc)]})

    def do_GET(self):
        self._dispatch(
            {
                "/capabilities/version": self.api.get_version,
                "/config": self.api.get_config,
            }
        )

    def do_POST(self):
        self._dispatch(
            {
                "/config": lambda: self.api.set_config(self._body()),
                "/control/state": lambda: self.api.set_control_state(self._body()),
                "/control/action": lambda: self.api.set_control_action(self._body()),
                "/monitor/metrics": lambda: self.api.get_metrics(self._body()),
            }
        )


def build_server(api, address, port, cert=None, key=None):
    httpd = ThreadingHTTPServer((address, port), Handler)
    httpd.api = api
    httpd.daemon_threads = True

    if cert and key and os.path.isfile(cert) and os.path.isfile(key):
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(cert, key)
        httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
        scheme = "https"
    else:
        scheme = "http"

    return httpd, scheme


def main(argv=None):
    parser = argparse.ArgumentParser(description="dpdk-tgen OTG API server")
    parser.add_argument("--resources", required=True, help="resource template JSON")
    parser.add_argument("--listen", help="override the template's api_address")
    parser.add_argument("--port", type=int, help="override the template's api_port")
    parser.add_argument(
        "--no-tls", action="store_true", help="serve plain HTTP even if certs exist"
    )
    parser.add_argument(
        "--no-engine",
        action="store_true",
        help="attach to an engine that is already running",
    )
    parser.add_argument("--engine-log", help="file to capture engine output in")
    parser.add_argument(
        "--engine-binary", help="override the template's engine binary path"
    )
    parser.add_argument(
        "--unsafe-skip-port-check",
        action="store_true",
        help="start even if a configured port is one the kernel is using",
    )
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )

    resources = Resources.load(args.resources)
    if args.engine_binary:
        resources.doc.setdefault("engine", {})["binary"] = args.engine_binary

    if args.unsafe_skip_port_check:
        LOG.warning(
            "port safety check skipped; the engine may take over an interface "
            "the kernel is using"
        )
    else:
        try:
            preflight.check_ports(resources)
        except preflight.SafetyError as exc:
            LOG.error("%s", exc)
            return 1

    api = TgenApi(resources, engine_log=args.engine_log, own_engine=not args.no_engine)
    api.start()

    tls = resources.chassis.get("tls") or {}
    httpd, scheme = build_server(
        api,
        args.listen or resources.api_address,
        args.port or resources.api_port,
        None if args.no_tls else tls.get("cert"),
        None if args.no_tls else tls.get("key"),
    )

    def shutdown(signum, frame):
        LOG.info("signal %d, shutting down", signum)
        # shutdown() waits for serve_forever() to return, so calling it on
        # the thread that is inside serve_forever() deadlocks.
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    host, port = httpd.server_address[:2]
    LOG.info("OTG API on %s://%s:%d", scheme, host, port)
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()
        api.stop()
        LOG.info("stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
