"""Build and run the dpdk-tgen container from a resource template.

The JSON template owns image name, mounts, capabilities, and the CPU/NUMA
placement derived from ``resources.lcores``. InfiniBand verbs character
devices are derived from each port's PCI address unless listed explicitly in
``container.devices``.
"""

import argparse
import os
import shlex
import subprocess
import sys

from .resources import Resources

_SYS_PCI = "/sys/bus/pci/devices"
_VERBS_CLASS = "/sys/class/infiniband_verbs"

# mlx5 in bifurcated mode needs host sysfs inside the container; PMD plugins are
# staged separately at image build time.
_DEFAULT_MOUNTS = [
    {"source": "/sys/bus/pci/devices", "target": "/sys/bus/pci/devices", "readonly": True},
    {"source": "/sys/class/infiniband", "target": "/sys/class/infiniband", "readonly": True},
]


class LauncherError(RuntimeError):
    pass


def _pci_norm(pci):
    return pci.lower()


def ibverbs_devices_for_pci(pci):
    """Return /dev/infiniband/uverbs* paths for a PCI PF."""
    want = _pci_norm(pci)
    found = []

    if os.path.isdir(_VERBS_CLASS):
        for name in sorted(os.listdir(_VERBS_CLASS)):
            device = os.path.join(_VERBS_CLASS, name, "device")
            if not os.path.exists(device):
                continue
            real = os.path.realpath(device)
            if real.endswith("/" + want) or real.endswith(want):
                found.append("/dev/infiniband/" + name)

    # Fallback: mlx5 exposes verbs under the PCI device tree on some kernels.
    verbs_dir = os.path.join(_SYS_PCI, want, "infiniband_verbs")
    if os.path.isdir(verbs_dir):
        for entry in sorted(os.listdir(verbs_dir)):
            node = "/dev/infiniband/" + entry
            if os.path.exists(node):
                found.append(node)

    return sorted(set(found))


def container_devices(resources):
    """InfiniBand character devices passed into the container."""
    container = resources.doc.get("container") or {}
    listed = container.get("devices")
    if listed:
        return list(listed)

    devices = []
    for port in resources.ports:
        devices.extend(ibverbs_devices_for_pci(port.pci))
    return sorted(set(devices))


def cpuset_cpus(resources):
    lcores = resources.doc["resources"]["lcores"]
    order = [lcores["main"]] + list(lcores["tx"]) + list(lcores["rx"])
    return ",".join(str(c) for c in order)


def cpuset_mems(resources):
    return str(resources.doc["resources"].get("numa_node", 0))


def merge_mounts(mounts):
    """Append default sysfs mounts unless the template already sets them."""
    out = list(mounts)
    seen = {(m["source"], m["target"]) for m in out}
    for mount in _DEFAULT_MOUNTS:
        key = (mount["source"], mount["target"])
        if key not in seen:
            out.append(mount)
            seen.add(key)
    return out


def docker_run_argv(
    resources,
    resources_mount_path,
    detached=True,
    replace=False,
    extra_args=None,
):
    """Return argv for ``docker run`` (without the ``docker run`` prefix)."""
    container = resources.doc.get("container") or {}
    image = container.get("image")
    if not image:
        raise LauncherError("container.image is not set in the resource template")

    name = container.get("name", "dpdk-tgen")
    network = container.get("network", "host")
    memory = container.get("memory")
    capabilities = container.get("capabilities") or ["IPC_LOCK"]
    mounts = merge_mounts(container.get("mounts") or [])

    argv = ["docker", "run"]
    if detached:
        argv.append("-d")
    argv += ["--rm", "--name", name]

    if network == "host":
        argv.append("--network=host")
        # Share /dev/shm and IPC with the host (stats file, DPDK mp socket).
        argv.append("--ipc=host")
    elif network == "bridge":
        argv.append("--network=bridge")
    else:
        raise LauncherError("unsupported container.network %r" % network)

    argv += ["--cpuset-cpus", cpuset_cpus(resources)]
    argv += ["--cpuset-mems", cpuset_mems(resources)]

    if memory:
        argv += ["--memory", str(memory)]

    if container.get("privileged"):
        argv.append("--privileged")

    # ibverbs/DPDK pin hugepage-backed memory; the default memlock cap is too low.
    argv += ["--ulimit", "memlock=-1"]

    for cap in capabilities:
        argv += ["--cap-add", cap]

    for device in container_devices(resources):
        if not os.path.exists(device):
            raise LauncherError(
                "device %s does not exist on the host (needed for mlx5 in container)"
                % device
            )
        argv += ["--device", device]

    resources_abs = os.path.abspath(resources_mount_path)
    if not os.path.isfile(resources_abs):
        raise LauncherError("resource template not found: %s" % resources_abs)

    argv += [
        "-v",
        "%s:/etc/dpdk-tgen/resources.json:ro" % resources_abs,
    ]

    for mount in mounts:
        source = mount["source"]
        target = mount["target"]
        opt = "%s:%s" % (source, target)
        if mount.get("readonly"):
            opt += ":ro"
        argv += ["-v", opt]

    if extra_args:
        argv.extend(extra_args)

    argv.append(image)
    return argv


def format_command(argv):
    return " ".join(shlex.quote(a) for a in argv)


def cmd_run(args):
    resources = Resources.load(args.resources, validate=not args.skip_validate)
    argv = docker_run_argv(
        resources,
        args.resources,
        detached=not args.foreground,
        replace=args.replace,
        extra_args=args.docker_arg,
    )

    if args.print_only:
        print(format_command(argv))
        return 0

    if args.replace:
        subprocess.call(
            ["docker", "rm", "-f", (resources.doc.get("container") or {}).get("name", "dpdk-tgen")],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    print("running:", format_command(argv))
    try:
        subprocess.check_call(argv)
    except subprocess.CalledProcessError as exc:
        raise LauncherError("docker run failed with exit code %d" % exc.returncode)
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--resources",
        default="config/sonic-tb14.json",
        help="resource template JSON (mounted into the container)",
    )
    parser.add_argument(
        "--skip-validate",
        action="store_true",
        help="skip JSON schema validation",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    run_p = sub.add_parser("run", help="start the container")
    run_p.add_argument(
        "--foreground",
        action="store_true",
        help="run attached (default is detached -d)",
    )
    run_p.add_argument(
        "--replace",
        action="store_true",
        help="remove any existing container with the same name first",
    )
    run_p.add_argument(
        "--print-only",
        action="store_true",
        help="print docker run command and exit",
    )
    run_p.add_argument(
        "--docker-arg",
        action="append",
        default=[],
        metavar="ARG",
        help="extra argument to pass to docker run (repeatable)",
    )

    cmd_p = sub.add_parser("cmd", help="print docker run command only")
    cmd_p.add_argument(
        "--docker-arg",
        action="append",
        default=[],
        metavar="ARG",
    )

    args = parser.parse_args(argv)

    if args.command == "cmd":
        args.print_only = True
        args.foreground = False
        args.replace = False
        return cmd_run(args)

    if args.command == "run":
        try:
            return cmd_run(args)
        except LauncherError as exc:
            print("error: %s" % exc, file=sys.stderr)
            return 1

    return 1


if __name__ == "__main__":
    sys.exit(main())
