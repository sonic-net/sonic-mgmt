"""Fail-safe checks, all of which decide without transmitting anything.

The generator sends at line rate, so a mistake is not something to detect
afterwards. Two questions have to be answered before the first frame leaves:
which hardware will transmit, and what will it transmit. Both are answerable
from configuration and from the kernel's own state, so neither needs a test
packet -- a test packet aimed at the wrong place has already done the damage
it was meant to detect.

**Which hardware.** DPDK's ``-a`` allowlist means only the ports named in the
resource template are ever probed, so this reduces to whether the template
names the right devices. ``check_ports`` answers that from ``/sys``: a port
is safe to drive only when the kernel is not using it. This matters more than
it looks, because mlx5 is a bifurcated driver -- the kernel keeps its netdev
while DPDK drives the same hardware -- so putting a management port into
promiscuous mode would take that machine's own traffic away from the kernel.

**What will it transmit.** ``check_flow`` rejects any frame that could
propagate beyond the link it is sent on: broadcast and multicast
destinations, which a switch floods everywhere, and destination addresses
that the kernel would route off this machine or that are globally routable.

Neither check makes traffic, and neither can be satisfied by accident.
Everything here reads ``/sys`` and ``/proc`` or makes an ioctl, so it behaves
the same inside a container with no iproute2 installed.
"""

import fcntl
import ipaddress
import logging
import os
import socket
import struct

LOG = logging.getLogger(__name__)

SIOCGIFADDR = 0x8915
SIOCGIFHWADDR = 0x8927

_SYS_PCI = "/sys/bus/pci/devices"
_SYS_NET = "/sys/class/net"

# Address space a traffic generator has any business sourcing or targeting.
# 198.18.0.0/15 is reserved by RFC 2544 for exactly this, the rest is private
# or documentation space. Anything outside this is refused, so a typo cannot
# put a globally routable address on the wire.
DEFAULT_ALLOWED_IPV4 = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("198.18.0.0/15"),  # RFC 2544 benchmarking
    ipaddress.ip_network("192.0.2.0/24"),  # TEST-NET-1
    ipaddress.ip_network("198.51.100.0/24"),  # TEST-NET-2
    ipaddress.ip_network("203.0.113.0/24"),  # TEST-NET-3
]


def allowed_ipv4_subnets(resources):
    """Default private and benchmark space, plus any extra prefixes in the template."""
    extra = []
    for cidr in resources.allowed_ipv4_subnets:
        extra.append(ipaddress.ip_network(cidr, strict=False))
    return DEFAULT_ALLOWED_IPV4 + extra


class SafetyError(RuntimeError):
    pass


def netdevs_for_pci(pci):
    """Kernel interface names sharing hardware with a PCI device."""
    path = os.path.join(_SYS_PCI, pci, "net")
    if not os.path.isdir(path):
        return []
    return sorted(os.listdir(path))


def ipv4_address(ifname):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        packed = fcntl.ioctl(
            sock.fileno(), SIOCGIFADDR, struct.pack("256s", ifname[:15].encode())
        )
        return socket.inet_ntoa(packed[20:24])
    except OSError:
        return None
    finally:
        sock.close()


def ipv6_addresses(ifname):
    """Global IPv6 addresses. Link-local ones exist on every up interface."""
    found = []
    try:
        with open("/proc/net/if_inet6") as handle:
            for line in handle:
                fields = line.split()
                if len(fields) < 6 or fields[5] != ifname:
                    continue
                if fields[3] == "20":  # link-local scope
                    continue
                packed = bytes.fromhex(fields[0])
                found.append(socket.inet_ntop(socket.AF_INET6, packed))
    except OSError:
        pass
    return found


def routes_for(ifname):
    """Every IPv4 route through an interface, the default route named first."""
    found = []
    try:
        with open("/proc/net/route") as handle:
            next(handle)  # header
            for line in handle:
                fields = line.split()
                if len(fields) < 8 or fields[0] != ifname:
                    continue
                destination = socket.inet_ntoa(struct.pack("<I", int(fields[1], 16)))
                mask = bin(int(fields[7], 16)).count("1")
                if destination == "0.0.0.0" and mask == 0:
                    found.insert(0, "default")
                else:
                    found.append("%s/%d" % (destination, mask))
    except (OSError, StopIteration):
        pass
    return found


def mac_address(ifname):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        packed = fcntl.ioctl(
            sock.fileno(), SIOCGIFHWADDR, struct.pack("256s", ifname[:15].encode())
        )
        return ":".join("%02x" % b for b in packed[18:24])
    except OSError:
        return None
    finally:
        sock.close()


def specific_route_interface_for(address):
    """The interface that has a route covering this address, ignoring default.

    The default route matches everything, so counting it would condemn every
    address. What matters here is whether some interface on this machine
    claims the address specifically -- a connected subnet, a bridge, a static
    route -- because that is what identifies an address as belonging to a
    network this machine is attached to. Returns None for an address nothing
    claims, which is the expected answer for a device under test hanging off
    an unaddressed port.
    """
    target = int(ipaddress.ip_address(address))
    best_length = -1
    best_interface = None

    try:
        with open("/proc/net/route") as handle:
            next(handle)
            for line in handle:
                fields = line.split()
                if len(fields) < 8:
                    continue
                destination = struct.unpack("<I", bytes.fromhex(fields[1]))[0]
                mask = struct.unpack("<I", bytes.fromhex(fields[7]))[0]
                if mask == 0:
                    continue
                if (target & mask) != (destination & mask):
                    continue
                length = bin(mask).count("1")
                if length > best_length:
                    best_length = length
                    best_interface = fields[0]
    except (OSError, StopIteration, ValueError):
        return None

    return best_interface


def master_of(ifname):
    """The bridge or bond an interface is enslaved to, if any."""
    link = os.path.join(_SYS_NET, ifname, "master")
    return os.path.basename(os.readlink(link)) if os.path.islink(link) else None


def default_route_interface():
    for entry in os.listdir(_SYS_NET):
        if "default" in routes_for(entry):
            return entry
    return None


def inspect(pci):
    """Everything the kernel knows about a candidate traffic port."""
    if not os.path.isdir(os.path.join(_SYS_PCI, pci)):
        raise SafetyError("PCI device %s does not exist on this machine" % pci)

    report = {"pci": pci, "netdevs": []}
    for ifname in netdevs_for_pci(pci):
        report["netdevs"].append(
            {
                "name": ifname,
                "ipv4": ipv4_address(ifname),
                "ipv6": ipv6_addresses(ifname),
                "routes": routes_for(ifname),
                "master": master_of(ifname),
            }
        )
    return report


def traffic_interfaces(resources):
    """Kernel interface names belonging to the generator's own ports."""
    names = set()
    for port in resources.ports:
        names.update(netdevs_for_pci(port.pci))
    return names


def _is_multicast_mac(mac):
    """True for multicast and broadcast, which differ only in the address."""
    return bool(int(mac.split(":")[0], 16) & 1)


def check_flow(flow, resources):
    """Raise unless a flow's frames are confined to the link they leave on.

    Called for every flow before it reaches the engine, so a configuration
    that could reach beyond the cable is refused rather than transmitted and
    regretted.
    """
    ours = traffic_interfaces(resources)
    where = "flow %s" % flow.name

    if flow.dst_mac:
        mac = flow.dst_mac.lower().replace("-", ":")
        if _is_multicast_mac(mac):
            raise SafetyError(
                "%s: destination MAC %s is broadcast or multicast. A switch "
                "floods those to every port, so a miscabled generator would "
                "reach the whole network. Traffic must be unicast to a known "
                "peer." % (where, flow.dst_mac)
            )
        for ifname in sorted(set(os.listdir(_SYS_NET)) - ours):
            if mac_address(ifname) == mac:
                raise SafetyError(
                    "%s: destination MAC %s belongs to this machine's %s "
                    "interface. Traffic must be addressed to the device under "
                    "test, not back into the host."
                    % (where, flow.dst_mac, ifname)
                )

    permitted = allowed_ipv4_subnets(resources)
    for role, address in (("source", flow.src_ip), ("destination", flow.dst_ip)):
        parsed = ipaddress.ip_address(address)
        if not any(parsed in subnet for subnet in permitted):
            raise SafetyError(
                "%s: %s address %s is outside the address space a traffic "
                "generator may use. Allowed: %s."
                % (
                    where,
                    role,
                    address,
                    ", ".join(str(subnet) for subnet in permitted),
                )
            )

    carrier = specific_route_interface_for(flow.dst_ip)
    if carrier is not None and carrier not in ours:
        raise SafetyError(
            "%s: destination %s is on a network this machine is attached to "
            "through %s. Sending to it would put generated traffic on that "
            "network. Pick an address no interface here claims."
            % (where, flow.dst_ip, carrier)
        )


def check_ports(resources):
    """Raise unless every configured port is safe for the engine to drive.

    A port is safe when the kernel is not using it: no addresses, no routes,
    not enslaved to a bridge or bond. That is exactly the state of a port
    whose only job is to be cabled to a device under test.
    """
    mgmt = default_route_interface()
    problems = []
    reports = []

    for port in resources.ports:
        report = inspect(port.pci)
        reports.append((port, report))

        for dev in report["netdevs"]:
            where = "%s (%s, %s)" % (port.location, port.pci, dev["name"])

            if dev["name"] == mgmt:
                problems.append(
                    "%s is this machine's management interface and carries the "
                    "default route" % where
                )
                continue
            if dev["ipv4"]:
                problems.append("%s has the address %s" % (where, dev["ipv4"]))
            if dev["ipv6"]:
                problems.append(
                    "%s has the address %s" % (where, ", ".join(dev["ipv6"]))
                )
            if dev["routes"]:
                problems.append(
                    "%s carries routes: %s" % (where, ", ".join(dev["routes"]))
                )
            if dev["master"]:
                problems.append("%s is enslaved to %s" % (where, dev["master"]))

    if problems:
        raise SafetyError(
            "refusing to start, the resource template names ports the kernel is "
            "still using:\n  - "
            + "\n  - ".join(problems)
            + "\n\nThe generator transmits at line rate and puts its ports into "
            "promiscuous mode. Check the 'pci' values in "
            + (resources.source or "the resource template")
            + "."
        )

    for port, report in reports:
        names = ", ".join(d["name"] for d in report["netdevs"]) or "none"
        LOG.info(
            "port %s is %s, kernel interface %s, unaddressed and unrouted",
            port.location,
            port.pci,
            names,
        )
    LOG.info("management interface %s is not among the configured ports", mgmt)
