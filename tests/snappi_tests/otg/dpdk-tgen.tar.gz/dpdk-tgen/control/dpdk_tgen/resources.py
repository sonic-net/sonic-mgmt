"""Resource template: the machine and hardware facts the engine needs.

Everything that depends on the box the generator runs on lives here, so the
OTG configuration a snappi client sends carries only traffic intent. See
``config/resources.schema.json`` for the contract.
"""

import json
import os

_SCHEMA_RELATIVE = os.path.join("config", "resources.schema.json")


def _find_schema(start):
    """Walk up from the template looking for the repository's schema."""
    path = os.path.abspath(start)
    while True:
        parent = os.path.dirname(path)
        if parent == path:
            return None
        candidate = os.path.join(parent, _SCHEMA_RELATIVE)
        if os.path.isfile(candidate):
            return candidate
        path = parent


class Port(object):
    def __init__(self, entry, index):
        self.index = index
        self.card = entry["card"]
        self.port = entry["port"]
        self.pci = entry["pci"]
        self.speed_mbps = entry.get("speed_mbps", 100000)
        self.mtu = entry.get("mtu", 9000)

    @property
    def location(self):
        """The string a snappi client puts in ``port.location``."""
        return "Card%d/Port%d" % (self.card, self.port)

    def __repr__(self):
        return "<Port %s %s index=%d>" % (self.location, self.pci, self.index)


class Resources(object):
    def __init__(self, doc, source=None):
        self.doc = doc
        self.source = source
        self.ports = [Port(entry, i) for i, entry in enumerate(doc["ports"])]

        seen = {}
        for port in self.ports:
            if port.location in seen:
                raise ValueError("duplicate port location %s" % port.location)
            seen[port.location] = port
        self._by_location = seen

    @classmethod
    def load(cls, path, validate=True):
        with open(path) as handle:
            doc = json.load(handle)
        obj = cls(doc, source=os.path.abspath(path))
        if validate:
            obj.validate()
        return obj

    def validate(self):
        schema_path = _find_schema(self.source or __file__)
        if schema_path is None:
            return
        try:
            import jsonschema
        except ImportError:
            return
        with open(schema_path) as handle:
            jsonschema.validate(self.doc, json.load(handle))

    def port_by_location(self, location):
        return self._by_location.get(location)

    # Sections, with the defaults the schema documents.

    @property
    def chassis(self):
        return self.doc["chassis"]

    @property
    def engine(self):
        return self.doc.get("engine", {})

    @property
    def api_address(self):
        return self.chassis.get("api_address", "0.0.0.0")

    @property
    def api_port(self):
        return int(self.chassis.get("api_port", 8443))

    @property
    def shm_path(self):
        return self.engine.get("shm_path", "/dev/shm/dpdk-tgen-stats")

    @property
    def socket_path(self):
        return self.engine.get("socket_path", "/var/run/dpdk-tgen.sock")

    @property
    def binary(self):
        return self.engine.get("binary", "/usr/local/bin/dpdk-tgen-engine")

    @property
    def strict_unsupported(self):
        return bool(self.engine.get("strict_unsupported", False))

    @property
    def allowed_ipv4_subnets(self):
        """Extra IPv4 prefixes permitted in flows, in addition to the built-in set."""
        return list(self.engine.get("allowed_ipv4_subnets", []))

    def eal_args(self):
        """Build the EAL argument list from the template.

        The lcore list is written out explicitly rather than as a range so
        that the engine's main, transmit and receive lcores are exactly the
        ones the template pinned, in that order.
        """
        res = self.doc["resources"]
        lcores = res["lcores"]
        order = [lcores["main"]] + list(lcores["tx"]) + list(lcores["rx"])

        args = ["-l", ",".join(str(c) for c in order), "-n", "4"]

        socket_mem = res.get("socket_mem_mb")
        if socket_mem:
            args += ["--socket-mem", ",".join(str(m) for m in socket_mem)]

        dpdk = self.doc.get("dpdk", {})
        if dpdk.get("file_prefix"):
            args += ["--file-prefix", dpdk["file_prefix"]]

        for port in self.ports:
            args += ["-a", port.pci]

        args += list(dpdk.get("extra_eal_args", []))
        return args

    def engine_args(self):
        """Arguments after the EAL separator."""
        mtu = max(port.mtu for port in self.ports) if self.ports else 9000
        return [
            "--server",
            "--socket-path",
            self.socket_path,
            "--shm-path",
            self.shm_path,
            "--frame-size",
            str(mtu),
        ]

    def command_line(self):
        return [self.binary] + self.eal_args() + ["--"] + self.engine_args()
