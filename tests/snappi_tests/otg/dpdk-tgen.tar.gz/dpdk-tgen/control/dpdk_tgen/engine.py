"""Supervision of, and the command channel to, the C++ data plane.

The engine owns the hugepages, the NICs and the lcores; it is started once
and lives for as long as the control process does. Everything the control
process asks of it goes over a line-oriented Unix socket, and everything it
reports comes back through shared memory.
"""

import logging
import os
import socket
import subprocess
import time

LOG = logging.getLogger(__name__)


class EngineError(RuntimeError):
    pass


class CommandClient(object):
    """Line protocol client. Replies are ``OK``/``ERR`` plus key=value pairs."""

    def __init__(self, path, timeout=10.0):
        self.path = path
        self.timeout = timeout
        self._sock = None
        self._file = None

    def connect(self, retries=1, delay=0.2):
        last = None
        for _ in range(max(1, retries)):
            try:
                sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                sock.settimeout(self.timeout)
                sock.connect(self.path)
                self._sock = sock
                self._file = sock.makefile("rw")
                return self
            except (socket.error, OSError) as exc:
                last = exc
                time.sleep(delay)
        raise EngineError("cannot connect to %s: %s" % (self.path, last))

    def close(self):
        for obj in (self._file, self._sock):
            if obj is not None:
                try:
                    obj.close()
                except OSError:
                    pass
        self._file = None
        self._sock = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def send(self, verb, **kwargs):
        """Send one command and return its key=value pairs.

        Raises on ``ERR`` so callers do not have to check every reply.
        """
        if self._file is None:
            raise EngineError("not connected")

        parts = [verb] + ["%s=%s" % (k, v) for k, v in sorted(kwargs.items())]
        line = " ".join(parts)
        LOG.debug("-> %s", line)

        self._file.write(line + "\n")
        self._file.flush()
        reply = self._file.readline()
        if not reply:
            raise EngineError("engine closed the command socket")
        reply = reply.strip()
        LOG.debug("<- %s", reply)

        if not reply.startswith("OK"):
            raise EngineError("%s: %s" % (verb, reply))

        result = {}
        for token in reply.split()[1:]:
            if "=" in token:
                key, value = token.split("=", 1)
                result[key] = value
        return result


class EngineProcess(object):
    """Starts the engine binary and waits until it is ready to be driven."""

    def __init__(self, resources, log_path=None):
        self.resources = resources
        self.log_path = log_path
        self.proc = None
        self._log = None

    def start(self, timeout=30.0):
        argv = self.resources.command_line()
        LOG.info("starting engine: %s", " ".join(argv))

        # A stale socket from a killed engine would make the readiness check
        # succeed instantly against nothing.
        try:
            os.unlink(self.resources.socket_path)
        except OSError:
            pass

        if self.log_path:
            self._log = open(self.log_path, "ab", 0)
            stdout = self._log
        else:
            stdout = None

        self.proc = subprocess.Popen(argv, stdout=stdout, stderr=subprocess.STDOUT)
        self._wait_ready(timeout)
        LOG.info("engine ready, pid %d", self.proc.pid)
        return self

    def _wait_ready(self, timeout):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.proc.poll() is not None:
                raise EngineError(
                    "engine exited with status %d before becoming ready%s"
                    % (
                        self.proc.returncode,
                        " (see %s)" % self.log_path if self.log_path else "",
                    )
                )
            if os.path.exists(self.resources.socket_path):
                try:
                    with CommandClient(self.resources.socket_path).connect() as cmd:
                        cmd.send("PING")
                    return
                except EngineError:
                    pass
            time.sleep(0.25)
        raise EngineError("engine did not become ready within %.0fs" % timeout)

    def stop(self, timeout=10.0):
        if self.proc is None:
            return
        if self.proc.poll() is None:
            try:
                with CommandClient(self.resources.socket_path).connect() as cmd:
                    cmd.send("QUIT")
            except EngineError:
                self.proc.terminate()
            try:
                self.proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                LOG.warning("engine did not exit, killing")
                self.proc.kill()
                self.proc.wait()
        if self._log is not None:
            self._log.close()
            self._log = None
        self.proc = None

    @property
    def running(self):
        return self.proc is not None and self.proc.poll() is None
