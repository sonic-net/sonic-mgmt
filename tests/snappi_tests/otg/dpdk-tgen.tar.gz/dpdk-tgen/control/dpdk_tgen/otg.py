"""Translation between an OTG configuration and what the engine understands.

Phase 1 supports one shape of traffic: a fixed-size UDP over IPv4 frame sent
from one port and counted on another. Rather than reject a configuration that
carries more than that, anything we cannot honour is collected as a warning
and returned to the client, so a snappi script written against a fuller
implementation still runs. Setting ``strict_unsupported`` in the resource
template turns those warnings into errors.
"""

import math

DEFAULT_SRC_IP = "10.0.0.1"
DEFAULT_DST_IP = "10.0.0.2"
DEFAULT_SRC_L4 = 5001
DEFAULT_DST_L4 = 5002

# Preamble, start-of-frame delimiter, FCS and inter-frame gap. Percentages of
# line rate are computed against the wire, not against the frame.
WIRE_OVERHEAD = 24

_SPEED_TO_MBPS = {
    "speed_10_mbps": 10,
    "speed_100_mbps": 100,
    "speed_1_gbps": 1000,
    "speed_10_gbps": 10000,
    "speed_25_gbps": 25000,
    "speed_40_gbps": 40000,
    "speed_50_gbps": 50000,
    "speed_100_gbps": 100000,
    "speed_200_gbps": 200000,
    "speed_400_gbps": 400000,
}

_BPS_MULTIPLIER = {"bps": 1, "kbps": 1e3, "mbps": 1e6, "gbps": 1e9}

# Flow keys we read. Anything else present draws a warning.
_KNOWN_FLOW_KEYS = {"name", "tx_rx", "packet", "size", "rate", "duration", "metrics"}


class ConfigError(ValueError):
    pass


class FlowSpec(object):
    """One flow, already reduced to the engine's CONFIGURE arguments."""

    def __init__(self, flow_id, name):
        self.flow_id = flow_id
        self.name = name
        self.tx_port = 0
        self.rx_port = 1
        self.frame_size = 9000
        self.rate_pps = 0
        self.duration_ms = 0
        self.src_mac = None
        self.dst_mac = None
        self.src_ip = DEFAULT_SRC_IP
        self.dst_ip = DEFAULT_DST_IP
        self.src_l4 = DEFAULT_SRC_L4
        self.dst_l4 = DEFAULT_DST_L4

    def command_kwargs(self):
        kwargs = {
            "flow_id": self.flow_id,
            "tx_port": self.tx_port,
            "rx_port": self.rx_port,
            "frame_size": self.frame_size,
            "rate_pps": self.rate_pps,
            "duration_ms": self.duration_ms,
            "src_ip": self.src_ip,
            "dst_ip": self.dst_ip,
            "src_l4": self.src_l4,
            "dst_l4": self.dst_l4,
        }
        if self.src_mac:
            kwargs["src_mac"] = self.src_mac
        if self.dst_mac:
            kwargs["dst_mac"] = self.dst_mac
        return kwargs


class TranslatedConfig(object):
    def __init__(self):
        self.flows = []
        self.ports = []  # (otg name, resources.Port)
        self.warnings = []
        self.raw = None

    def resource_port(self, name):
        """The chassis port an OTG port name resolves to."""
        for otg_name, port in self.ports:
            if otg_name == name:
                return port
        raise ConfigError("flow refers to unknown port %r" % name)

    def port_index(self, name):
        # The engine's port index is the template's, which need not match the
        # order the client happened to list its ports in.
        return self.resource_port(name).index

    def flow_by_name(self, name):
        for flow in self.flows:
            if flow.name == name:
                return flow
        return None


def _scalar(pattern, what, warnings, default=None):
    """Pull a single value out of an OTG pattern object."""
    if pattern is None:
        return default
    if not isinstance(pattern, dict):
        return pattern

    if pattern.get("value") is not None:
        return pattern["value"]

    values = pattern.get("values")
    if values:
        if len(values) > 1:
            warnings.append(
                "%s: only the first of %d values is used, patterns are not "
                "supported in phase 1" % (what, len(values))
            )
        return values[0]

    for unsupported in ("increment", "decrement", "random"):
        if pattern.get(unsupported) is not None:
            warnings.append(
                "%s: %s patterns are not supported, using the start value"
                % (what, unsupported)
            )
            start = pattern[unsupported].get("start")
            if start is not None:
                return start
    return default


def _translate_packet(headers, flow, warnings):
    for header in headers or []:
        choice = header.get("choice")
        if choice is None:
            # snappi omits "choice" when only one header key is set.
            keys = [k for k in header if k != "choice"]
            choice = keys[0] if len(keys) == 1 else None

        body = header.get(choice) or {}
        label = "flow %s %s" % (flow.name, choice)

        if choice == "ethernet":
            flow.src_mac = _scalar(body.get("src"), label + ".src", warnings, flow.src_mac)
            flow.dst_mac = _scalar(body.get("dst"), label + ".dst", warnings, flow.dst_mac)
            if body.get("ether_type") is not None:
                warnings.append(label + ": ether_type is fixed at IPv4")
            if body.get("pfc_queue") is not None:
                warnings.append(label + ": pfc_queue is not supported")
        elif choice == "ipv4":
            flow.src_ip = _scalar(body.get("src"), label + ".src", warnings, flow.src_ip)
            flow.dst_ip = _scalar(body.get("dst"), label + ".dst", warnings, flow.dst_ip)
            for field in ("priority", "dscp", "identification", "flags", "time_to_live"):
                if body.get(field) is not None:
                    warnings.append("%s: %s is not supported" % (label, field))
        elif choice == "udp":
            flow.src_l4 = int(
                _scalar(body.get("src_port"), label + ".src_port", warnings, flow.src_l4)
            )
            flow.dst_l4 = int(
                _scalar(body.get("dst_port"), label + ".dst_port", warnings, flow.dst_l4)
            )
        else:
            warnings.append(
                "flow %s: header %r is not supported and was dropped; the frame "
                "is always ethernet/ipv4/udp in phase 1" % (flow.name, choice)
            )


def _translate_size(size, flow, warnings):
    if not size:
        return
    choice = size.get("choice", "fixed")
    if choice == "fixed":
        flow.frame_size = int(size.get("fixed", flow.frame_size))
    else:
        warnings.append(
            "flow %s: frame size %r is not supported, using %d bytes"
            % (flow.name, choice, flow.frame_size)
        )


def _translate_rate(rate, flow, speed_mbps, warnings):
    """Resolve any OTG rate form to packets per second.

    Percentages are of line rate, so they include the inter-frame gap and
    preamble. Bit rates are of frame bits, so they do not.
    """
    if not rate:
        return
    choice = rate.get("choice", "percentage")
    wire_bits = (flow.frame_size + WIRE_OVERHEAD) * 8.0

    if choice == "pps":
        flow.rate_pps = int(rate.get("pps", 0))
    elif choice == "percentage":
        percent = float(rate.get("percentage", 100.0))
        if percent >= 100.0:
            flow.rate_pps = 0  # unthrottled, the transmit loop is the limit
        else:
            flow.rate_pps = int(speed_mbps * 1e6 * percent / 100.0 / wire_bits)
    elif choice in _BPS_MULTIPLIER:
        bits = float(rate.get(choice, 0)) * _BPS_MULTIPLIER[choice]
        flow.rate_pps = int(bits / (flow.frame_size * 8.0))
    else:
        warnings.append("flow %s: rate %r is not supported" % (flow.name, choice))


def _translate_duration(duration, flow, warnings):
    if not duration:
        return
    choice = duration.get("choice", "continuous")

    if choice == "continuous":
        flow.duration_ms = 0
    elif choice == "fixed_seconds":
        seconds = float((duration.get("fixed_seconds") or {}).get("seconds", 0))
        flow.duration_ms = int(seconds * 1000)
    elif choice == "fixed_packets":
        packets = int((duration.get("fixed_packets") or {}).get("packets", 0))
        if flow.rate_pps == 0:
            warnings.append(
                "flow %s: fixed_packets needs an explicit rate to be converted "
                "to a duration, transmitting continuously instead" % flow.name
            )
            flow.duration_ms = 0
        else:
            # The engine stops on elapsed time, not on a packet count, so the
            # transmitted total lands near the request rather than on it.
            flow.duration_ms = int(math.ceil(packets * 1000.0 / flow.rate_pps))
            warnings.append(
                "flow %s: fixed_packets is approximated as a %d ms duration"
                % (flow.name, flow.duration_ms)
            )
    else:
        warnings.append("flow %s: duration %r is not supported" % (flow.name, choice))


def translate(config, resources):
    """Turn an OTG config document into flow specs the engine can accept."""
    out = TranslatedConfig()
    out.raw = config
    warnings = out.warnings

    otg_ports = config.get("ports") or []
    if not otg_ports:
        raise ConfigError("configuration has no ports")

    for entry in otg_ports:
        name = entry.get("name")
        location = entry.get("location")
        if not location:
            raise ConfigError("port %r has no location" % name)
        port = resources.port_by_location(location)
        if port is None:
            known = ", ".join(p.location for p in resources.ports)
            raise ConfigError(
                "port %r location %r is not on this chassis (have: %s)"
                % (name, location, known)
            )
        out.ports.append((name, port))

    # Layer 1 only ever narrows what the template already fixed, so a
    # mismatch is worth saying out loud but is not fatal.
    for layer1 in config.get("layer1") or []:
        for port_name in layer1.get("port_names") or []:
            port = dict(out.ports).get(port_name)
            if port is None:
                continue
            speed = layer1.get("speed")
            if speed and _SPEED_TO_MBPS.get(speed, port.speed_mbps) != port.speed_mbps:
                warnings.append(
                    "layer1 %s: port %s runs at %d Mbps, requested speed %s is "
                    "ignored" % (layer1.get("name"), port_name, port.speed_mbps, speed)
                )
            mtu = layer1.get("mtu")
            if mtu and int(mtu) != port.mtu:
                warnings.append(
                    "layer1 %s: port %s MTU is fixed at %d by the resource "
                    "template, requested %s is ignored"
                    % (layer1.get("name"), port_name, port.mtu, mtu)
                )
            if layer1.get("flow_control") is not None:
                warnings.append("layer1: flow_control is not supported in phase 1")
            if layer1.get("auto_negotiate") is not None:
                warnings.append("layer1: auto_negotiate is not supported in phase 1")

    for unsupported in ("captures", "devices", "lags", "lldp"):
        if config.get(unsupported):
            warnings.append("%s are not supported in phase 1" % unsupported)

    otg_flows = config.get("flows") or []
    for index, entry in enumerate(otg_flows):
        name = entry.get("name") or "flow%d" % index
        flow = FlowSpec(index, name)

        for key in entry:
            if key not in _KNOWN_FLOW_KEYS:
                warnings.append("flow %s: %r is not supported" % (name, key))

        tx_rx = entry.get("tx_rx") or {}
        if tx_rx.get("choice", "port") != "port":
            raise ConfigError(
                "flow %s: only port-to-port endpoints are supported, got %r"
                % (name, tx_rx.get("choice"))
            )
        endpoint = tx_rx.get("port") or {}
        tx_name = endpoint.get("tx_name")
        rx_names = endpoint.get("rx_names") or (
            [endpoint["rx_name"]] if endpoint.get("rx_name") else []
        )
        if not tx_name or not rx_names:
            raise ConfigError("flow %s: tx_rx.port needs tx_name and rx_names" % name)
        if len(rx_names) > 1:
            warnings.append(
                "flow %s: only the first receive port %s is counted"
                % (name, rx_names[0])
            )

        flow.tx_port = out.port_index(tx_name)
        flow.rx_port = out.port_index(rx_names[0])

        _translate_packet(entry.get("packet"), flow, warnings)
        _translate_size(entry.get("size"), flow, warnings)
        _translate_rate(
            entry.get("rate"), flow, out.resource_port(tx_name).speed_mbps, warnings
        )
        _translate_duration(entry.get("duration"), flow, warnings)

        out.flows.append(flow)

    if len(out.flows) > 1:
        warnings.append(
            "%d flows configured; phase 1 has only been validated with one"
            % len(out.flows)
        )

    return out
