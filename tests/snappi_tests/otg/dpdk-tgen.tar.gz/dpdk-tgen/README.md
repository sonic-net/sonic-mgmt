# dpdk-tgen

A DPDK-based traffic generator exposing a subset of the Open Traffic Generator
(OTG) REST API, so that `snappi` clients can drive it.

Target hardware is a Mellanox ConnectX-4 (`mlx5`) at 100G. Note that mlx5 ports
stay bound to `mlx5_core` and are reached through ibverbs; they are *not* bound
to `vfio-pci`.

## Phase 1 scope

Phase 1 is deliberately narrow: a single unidirectional flow at line rate, with
start, stop, and counters.

| Stage | Deliverable |
| ----- | ----------- |
| 1a | Standalone engine. One flow, port 0 to port 1, counters reconciled against `rte_eth_stats_get`. Done. |
| 1b | Python control process and OTG REST subset. Driven by a snappi script, ports cabled back to back. Done. |
| 1c | Same test through a real DUT (`tests/dut_flow.py`, `docs/phase1c-dut.md`). Generator path done; DUT counter sign-off optional flags. |
| 1d | Container image (`docker/Dockerfile`) and launcher (`dpdk_tgen.launcher`, `scripts/run-container.sh`). |
| 1e | sonic-mgmt integration: inventory, connection graph, and a test running under pytest. |

Not in phase 1: ARP and neighbour state, capture, latency, multiple flows,
bidirectional line rate, layer1 and FEC, PFC and ECN, BGP and LACP.

Unsupported OTG fields are accepted and reported as warnings in the
`set_config` response rather than rejected. A strict mode turns them into
errors for debugging.

## Measured ceilings

Established with `testpmd` on the target hardware, and these are what the
engine is measured against:

- 1.29 Mpps / 93 Gbps at 9000 byte frames, unidirectional, measured with
  `testpmd`. A second transmit queue does not improve it, so the limit is PCIe
  rather than cores.
- 1.336 Mpps / 96.4 Gbps for the same case measured with this engine at stage
  1a, which is 96% of theoretical line rate and 3% above `testpmd`. Zero loss,
  and no hardware receive misses with a single receive core.
- 96.95 Gbps for the same case driven through snappi and the REST API at stage
  1b, so the control path costs nothing at line rate.
- Bidirectional traffic is limited to roughly 51 Gbps per port. The card is
  PCIe Gen3 x16, so full rate both ways needs a second card in another slot.
- 64 byte frames reach about 8.7 Mpps per core, against the 148 Mpps that 100G
  line rate would require. Small frame line rate is not achievable here.
- `rte_eth_dev_set_link_down` is unsupported on mlx5, so link state cannot be
  controlled from DPDK.

## Container (phase 1d)

On the traffic-generator host, after `make` and with Docker installed:

```bash
./scripts/stage-docker-libs.sh
docker build -f docker/Dockerfile -t dpdk-tgen:0.1 .
```

Stop bare metal and clear stale hugepage maps, then start the container:

```bash
./scripts/stop-host-server.sh
./scripts/cleanup-engine-state.sh
./scripts/run-container.sh --replace config/sonic-tb14.json
curl -s http://127.0.0.1:8443/capabilities/version
```

See `docs/phase1d-container.md` for tb14 acceptance notes.

Print the `docker run` line without starting:  
`PYTHONPATH=control python3 -m dpdk_tgen.launcher --resources config/sonic-tb14.json cmd`

## Layout

    src/        C++ data plane
    control/    Python control process and OTG REST server
    config/     JSON templates (resources, port location to PCI mapping)
    docker/     Container image
    scripts/    Build, sync, and container helpers

## Repository boundary

The sonic-mgmt side lives in a separate repository and talks to this one only
over the OTG REST API. It does not import any code from here.

The one place the two must agree is the port naming: the links CSV in
sonic-mgmt refers to ports as `Card1/Port1`, and `config/` maps those names to
PCI addresses. The mapping here is the source of truth.
