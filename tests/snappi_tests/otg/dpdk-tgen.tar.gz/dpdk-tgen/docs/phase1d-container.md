# Phase 1d — container (sonic-tb14)

## Build on the traffic-generator host

```bash
cd ~/dpdk-tgen
make -j$(nproc)
./scripts/stage-docker-libs.sh   # DPDK libs + mlx5 + mempool_ring PMDs
docker build -f docker/Dockerfile -t dpdk-tgen:0.1 .
```

Do not run the bare-metal server and the container at the same time (same PCI and `file-prefix`).

## Start

```bash
./scripts/stop-host-server.sh
./scripts/cleanup-engine-state.sh
./scripts/run-container.sh --replace config/sonic-tb14.json
curl -s http://127.0.0.1:8443/capabilities/version
```

`config/sonic-tb14.json` sets `container.privileged: true` and `memory: 16g` so DPDK can use hugepages and NUMA policy inside Docker. The launcher also passes `--ulimit memlock=-1` and mounts host sysfs for mlx5.

## Acceptance

When the two generator ports are cabled to a **DUT** (not looped to each other),
`tests/b2b_flow.py` is the wrong check — zero RX on Port2 is expected without
a back-to-back cable. Use the same OTG path as phase 1c:

```bash
export TGEN_API=http://127.0.0.1:8443
no_proxy=127.0.0.1,localhost

# See docs/phase1c-dut.md and config/phase1c-sonic-tb14.example.sh
python3 tests/dut_flow.py \
  --src-mac 94:40:c9:88:2e:24 \
  --dst-mac <DUT-MAC-on-tx-link> \
  --src-ip 20.1.1.0 \
  --dst-ip 20.1.2.0 \
  --rate-pps 200000 \
  --seconds 60
```

Generator path lossless (`frames_tx == frames_rx`) through the DUT is sufficient
to sign off 1d container parity with bare metal. Optional DUT counter flags match
full 1c sign-off.

### Recorded on tb14 (2026-09-28)

| Check | Result |
|--------|--------|
| Image build | Pass |
| Container up, both mlx5 ports probed | Pass |
| `GET /capabilities/version` | Pass |
| `b2b_flow.py` | N/A — ports on DUT, not looped |
| `dut_flow.py` via container | Run when DUT neighbours/routing are in place |
