# Phase 1c — traffic through a real DUT

Stage 1c runs the same unidirectional flow as 1b, but the two generator ports
cable to a device under test instead of each other. Acceptance requires the
generator path to be lossless **and** the DUT port counters to match what the
generator transmitted and received.

## Topology (sonic-tb14 example)

```
  TGEN Card1/Port1 (94:40:c9:88:2e:24) ---- DUT Ethernet16   20.1.1.0/31
  TGEN Card1/Port2 (94:40:c9:88:2e:25) ---- DUT Ethernet24   20.1.2.0/31
```

Traffic path:

1. Generator transmits on Port1 toward the DUT MAC on link 1.
2. DUT routes `src-ip` on /31 #1 to `dst-ip` on /31 #2 and forwards out the
   second interface.
3. Generator receives on Port2 and attributes packets by signature.

## DUT configuration

1. **/31 addresses** on both DUT interfaces (four hosts total). Example:
   - Ethernet16: `20.1.1.1/31` (generator flow uses `20.1.1.0`)
   - Ethernet24: `20.1.2.1/31` (generator flow uses `20.1.2.0`)

2. **IPv4 forwarding** enabled so the DUT routes between the two /31s.

3. **Static neighbours** on the DUT. The generator does **not** answer ARP.
   Without static entries the DUT shows `(incomplete)` for `20.1.1.0` and
   `20.1.2.0` and forwarded traffic never returns.

   Example (adjust interface names):

   ```bash
   sudo ip neigh replace 20.1.1.0 lladdr 94:40:c9:88:2e:24 dev Ethernet16 nud permanent
   sudo ip neigh replace 20.1.2.0 lladdr 94:40:c9:88:2e:25 dev Ethernet24 nud permanent
   ```

4. **Clear counters** before a measured run (SONiC):

   ```bash
   sonic-clear counters
   ```

## Run the acceptance test (on sonic-tb14)

Start the control server and engine (see README). Then:

```bash
export TGEN_API=http://127.0.0.1:8443
cd ~/dpdk-tgen

python3 tests/dut_flow.py \
  --src-mac 94:40:c9:88:2e:24 \
  --dst-mac <DUT-MAC-on-Ethernet16> \
  --src-ip 20.1.1.0 \
  --dst-ip 20.1.2.0 \
  --rate-pps 200000 \
  --seconds 60
```

Collect DUT counters after the run (ingress on the transmit link, egress on
the receive link):

```bash
# On the DUT — note RX on Ethernet16 and TX on Ethernet24 for this flow direction
show interface counters -i Ethernet16 | grep RX_OK
show interface counters -i Ethernet24 | grep TX_OK
```

Re-run with DUT packet counts to complete 1c sign-off:

```bash
python3 tests/dut_flow.py \
  ...same MAC/IP/rate args... \
  --dut-ingress-rx <Ethernet16-RX-pkts> \
  --dut-egress-tx <Ethernet24-TX-pkts>
```

The script compares those values to generator `frames_tx` and `frames_rx`
within `--counter-tolerance` (default 0).

## What the test checks

| Check | Meaning |
| ----- | ------- |
| Generator flow `tx == rx` | Loop through DUT with signature intact |
| Flow vs port HW on tgen | Software counters match NIC counters on both ports |
| Optional DUT ingress RX | DUT received what the generator sent |
| Optional DUT egress TX | DUT forwarded what the generator received |

## Address allowlist

Only `20.1.1.0/31` and `20.1.2.0/31` are permitted in flows on sonic-tb14
(see `engine.allowed_ipv4_subnets` in `config/sonic-tb14.json`). Other
`20.x` addresses are refused at `set_config`.
