# dpdk-tgen — Phase 1 Design

Status: accepted. Stages 1a and 1b are met; 1c is implemented and measured on
the generator path with DUT counter reconciliation via `tests/dut_flow.py`;
1d is implemented on sonic-tb14 (image, launcher, API up); OTG acceptance with
the DUT topology uses `tests/dut_flow.py` (ports are not back-to-back). 1e is not started.

## 1. Purpose

A traffic generator built on DPDK that exposes a subset of the Open Traffic
Generator (OTG) REST API, so that `snappi` clients — including tests in
`sonic-mgmt` — can drive it.

Phase 1 delivers a single unidirectional flow at line rate with start, stop,
and counters, reachable over OTG, deployed as a container, and integrated into
the `sonic-mgmt` harness well enough to run one test of our own.

### 1.1 In scope

- One flow, one direction, fixed frame size, paced or unthrottled.
- Transmit and receive counters, per flow, reconciled against NIC counters.
- OTG endpoints: capabilities/version, `set_config`, `get_config`,
  `control/state`, `monitor/metrics`.
- Container image driven by a JSON resource template.
- `sonic-mgmt` inventory, connection graph, and one test of our own.

### 1.2 Explicitly out of scope

ARP and ND resolution, `get_states` and neighbour reporting, packet capture,
latency measurement, loss and reorder reporting, multiple concurrent flows,
bidirectional line rate, `layer1` configuration (speed, FEC, autonegotiation),
PFC and ECN, BGP and LACP emulation, and every existing test under
`tests/snappi_tests/`.

### 1.3 Deliberate exceptions to the scope cut

Two structural items are built in phase 1 although nothing in phase 1 reads
them, because retrofitting either means reworking the receive path:

- A flow identifier in the packet signature, and flow-indexed counter arrays.
- A sequence number in the packet signature.
- A transmit timestamp in the packet signature.

Everything else on the out-of-scope list is genuinely absent.

## 2. Target hardware and measured ceilings

Host `sonic-tb14`: Ubuntu 22.04.5, kernel 5.15, Intel with VT-d active, two
NUMA nodes (node 0 = CPUs 0-17 and 36-53, siblings at N and N+36).

NIC: Mellanox ConnectX-4, MT27700, `15b3:1013`, dual port, both at 100G, PCI
`0000:12:00.0` and `0000:12:00.1`, NUMA node 0, PCIe Gen3 x16.

Ports stay bound to `mlx5_core` and are reached through ibverbs. They are
**not** bound to `vfio-pci`; every `dpdk-devbind` instinct from Intel NICs is
wrong here.

The following were measured with `testpmd` and are the acceptance targets. The
engine is not expected to beat them.

| Condition | Result |
| --------- | ------ |
| 9000 byte frames, unidirectional | 1.29 Mpps, 93 Gbps — 93% of theoretical line rate |
| the same, measured with this engine at 1a | 1.336 Mpps, 96.4 Gbps — 96% of line rate, zero loss, no receive misses |
| 9000 byte frames, second tx queue | 1.294 Mpps — no improvement, so the limit is PCIe, not cores |
| 9000 byte frames, bidirectional | ~51 Gbps per port; ~103 Gbps per PCIe direction against a ~110 Gbps budget |
| 64 byte frames, 2 cores | 17.4 Mpps total, ~8.7 Mpps per core, against the 148 Mpps that line rate needs |

Consequences that shape the design: one core and one queue suffice, jumbo
frames are a standing requirement rather than a convenience, and full-rate
bidirectional traffic needs a second card in another slot.

## 3. Language and process structure

**Data plane: C++17.** The fast path is written as it would be in C — no
allocation, no exceptions, no RTTI, no virtual dispatch. C++ is used for
everything around it: port and mempool lifetime via RAII, typed configuration,
and the socket protocol.

Known friction, accepted: DPDK headers are C, so several inline functions
returning `void*` need explicit casts, `rte_pktmbuf_mtod` needs wrapping, and
DPDK's C designated-initializer style must be rewritten.

**Control plane: Python.** It owns the OTG REST server and all JSON handling.
Consequently no JSON parser is ever needed in C++.

**Parenthood.** The Python process starts the engine as a child and owns its
lifetime. There is no supervisor, no start ordering problem, and one entry
point to run. If the engine dies, Python reports it as an API error rather
than hanging.

## 4. Component boundaries

    control/   Python: OTG REST server, JSON, engine supervision
    src/       C++: DPDK data plane
    config/    JSON resource templates
    docker/    Container image
    scripts/   Build and sync helpers

The `sonic-mgmt` repository is separate and communicates only over the OTG REST
API. It imports no code from here.

## 5. Interface between control and data plane

Two channels, deliberately split by access pattern.

### 5.1 Statistics: shared memory

A file-backed shared mapping, written by the data plane, read by Python. No
locks and no atomics in the fast path; each lcore owns its own cache-aligned
block.

    struct ShmHeader {          // 40 bytes
        uint32_t magic;         // 'TGSM'
        uint32_t layout_version;
        uint32_t nb_lcores;
        uint32_t nb_flows;
        uint32_t nb_ports;
        uint32_t engine_state;  // 0 init 1 ready 2 running 3 stopping 4 error
        uint64_t tsc_hz;
        uint64_t start_tsc;
    };

    struct FlowCounters {       // 40 bytes
        uint64_t tx_pkts;
        uint64_t tx_bytes;
        uint64_t tx_fail;
        uint64_t rx_pkts;
        uint64_t rx_bytes;
    };

    struct LcoreBlock {         // cache aligned
        FlowCounters flow[MAX_FLOWS];
        uint64_t rx_unmatched;
        uint64_t tx_alloc_fail;
    };

    struct PortHwCounters {     // mirrors rte_eth_stats
        uint64_t opackets, obytes;
        uint64_t ipackets, ibytes;
        uint64_t imissed, ierrors, oerrors, rx_nombuf;
    };

Region layout is header, then `PortHwCounters[nb_ports]`, then
`LcoreBlock[nb_lcores]`.

Rules that keep this honest:

- Every struct is standard-layout POD with explicit sizes. A `static_assert`
  on `sizeof` and `offsetof` guards each one, and the Python side asserts the
  same numbers, so the two cannot drift silently.
- `layout_version` is bumped on any change and checked by Python at attach.
- Reads are **not** atomic snapshots. Counters are monotonic and summed on
  read, so skew is bounded by one read interval. This is acceptable for phase
  1 and is why acceptance criteria are evaluated after traffic stops rather
  than mid-flight.

### 5.2 Commands: Unix domain socket

Newline-terminated text, one command per line, one response per line. No JSON,
because the command surface in phase 1 is four verbs and a parser would be
larger than the thing it parses.

    -> CONFIGURE flow_id=0 tx_port=0 rx_port=1 frame_size=9000 rate_pps=1290000 \
                 src_mac=... dst_mac=... src_ip=... dst_ip=... duration_ms=0
    <- OK
    -> START
    <- OK
    -> STOP
    <- OK
    -> STATUS
    <- OK state=running flows=1

    <- ERR <message>

If this surface grows past phase 1, the intended replacement is a vendored
single-header JSON library, not an incrementally extended ad-hoc parser.

## 6. Wire format

Ethernet / IPv4 / UDP, followed by a fixed-offset signature.

    offset  0  ethernet    14
    offset 14  ipv4        20
    offset 34  udp          8
    offset 42  signature   24
    offset 66  payload     uninitialised to end of frame

    struct Signature {
        uint32_t magic;      // 'TGN1', network order
        uint16_t flow_id;    // network order
        uint16_t reserved;
        uint64_t seq;        // network order
        uint64_t tx_tsc;     // rte_rdtsc at transmit, network order
    };

Minimum frame is therefore 66 bytes; default is 9000. Everything in the
signature is network order, without exception, so there is one rule rather
than a per-field convention.

The signature is `__rte_packed` and starts at offset 42, so the two 64 bit
fields are not 8 byte aligned. This is deliberate: padding the signature to an
aligned offset would waste six bytes per packet to avoid an unaligned access
penalty that is negligible on x86 and irrelevant at 1.29 Mpps.

`tx_tsc` is unused in phase 1. It is present because both transmit and receive
run on the same host, and on this hardware the TSC is invariant and coherent
across cores, so latency can later be computed by subtracting at receive time
without PTP or hardware timestamping. Reserving it now costs 8 bytes per
packet and avoids a wire format change later.

The signature sits at a fixed offset so that the receive path is one load and
one compare rather than a header walk. Payload contents are not significant,
which is what allows the transmit path to avoid copying them (§7.3).

No VLAN tag in phase 1. The IPv4 header checksum is computed once at
configuration time because no field in it varies per packet. The UDP checksum
is zero, which is valid over IPv4 and keeps per-packet checksum work out of
the fast path.

## 7. Data plane

### 7.1 Threads

One main lcore for control and statistics, off the hot path. One transmit
lcore. One receive lcore. Cores come from the isolated set on node 0, so
`-l 2,3,4` maps main to 2, transmit to 3, receive to 4.

One receive queue and one transmit queue per port, since a second queue was
measured to add nothing.

### 7.2 Memory

A single mempool on node 0 with a data room of 10240 bytes, so a 9000 byte
frame occupies one segment and the fast path never handles scatter-gather.
16384 mbufs is roughly 168 MB against the 16 GB of 1G hugepages reserved on
node 0.

### 7.3 Transmit path

Per packet: allocate an mbuf, copy the 42 byte header template, write the 24
byte signature, set `pkt_len` and `data_len`. 66 bytes written in total.

The payload is deliberately left untouched. Copying a full 9000 byte template
at 1.29 Mpps would mean 11.6 GB/s of pointless memory traffic; writing 66
bytes instead is 0.7% of the frame and reduces that by more than two orders of
magnitude. This is the single most important performance decision in phase 1.

`RTE_ETH_TX_OFFLOAD_MBUF_FAST_FREE` is enabled when the port advertises it,
which is valid because all mbufs come from one pool with a refcount of one.

### 7.4 Pacing

A token bucket driven by `rte_rdtsc`, not a sleep loop.

    elapsed = min(now - last_tsc, tsc_hz)        // bound the multiply
    gained  = elapsed * rate_pps / tsc_hz
    tokens  = min(tokens + gained, TX_BURST)     // no burst after idle

Four details that matter and are easy to get wrong:

- `last_tsc` advances only when `gained` is non-zero, so fractional time is
  not discarded and the achieved rate does not drift low.
- `elapsed` is clamped so the multiply cannot overflow after a pause.
- Tokens are capped at one burst, so re-enabling transmit does not release a
  backlog.
- Only packets actually accepted by `rte_eth_tx_burst` consume tokens.

When `rate_pps` is zero the flow is unthrottled and offers a full burst every
iteration, which is how the 93 Gbps ceiling is reached.

On-wire frame size is `frame_size + 24` bytes — 4 FCS, 8 preamble and SFD, 12
inter-frame gap. All percentage-of-line-rate arithmetic converts to
packets per second through this one expression, at configuration time only.

### 7.5 Receive path

Burst receive, verify length, compare the signature magic, read `flow_id`,
increment `counters[lcore][flow_id]`, free.

Packets failing any check increment `rx_unmatched` rather than being
attributed to a flow. On a back-to-back or DUT setup this should be zero, and
a non-zero value means something else is on the wire.

### 7.6 Sequence number handling

`seq` increments per transmitted packet and is rewound by the number of
packets `rte_eth_tx_burst` refused, so the transmitted sequence space has no
gaps. Nothing in phase 1 reads it; the point is that when loss detection
arrives it does not have to distinguish real loss from self-inflicted gaps.

## 8. Counters and reconciliation

Every statistics interval the engine records both its own software counters
and `rte_eth_stats_get` for each port, and Python reports both.

This separation is the reason the DUT stage is diagnosable. Software transmit
against hardware `opackets` shows whether the engine or the NIC dropped a
packet; hardware `imissed` and `ierrors` on the receive port distinguish "the
wire lost it" from "we failed to poll fast enough"; `rx_nombuf` catches
mempool exhaustion.

Without this split, a discrepancy at the DUT stage has three indistinguishable
explanations. With it, one.

## 9. OTG API subset

| Endpoint | Purpose |
| -------- | ------- |
| `GET /capabilities/version` | Snappi performs a version check before anything else |
| `POST /config` | `set_config` |
| `GET /config` | `get_config` |
| `POST /control/state` | `set_control_state`, flow transmit start and stop |
| `POST /monitor/metrics` | `get_metrics`, `flow_metrics` and `port_metrics` |

Supported configuration fields are ports (name and location), and one flow
with `tx_rx.port`, an ethernet/ipv4/udp packet, `size.fixed`, `rate.pps` or
`rate.percentage`, `duration`, and `metrics.enable`.

Reported `flow_metrics` fields are `name`, `transmit`, `frames_tx`,
`frames_rx`, `bytes_tx`, `bytes_rx`, and the corresponding rates.

### 9.1 Unsupported fields

Anything not in the list above is **accepted and reported as a warning** in
the `set_config` response, which OTG provides for exactly this purpose, and
logged server side. It is never rejected.

This matters because the moment we are inside the `sonic-mgmt` harness,
fixtures will send `layer1`, PFC, and `devices` blocks. Rejecting them would
block integration on features that belong to a later phase.

The warning must be loud. Silently ignoring a PFC setting and then reporting a
clean pass is worse than failing outright, so a strict mode is available that
converts these warnings into errors while debugging.

TLS: the `sonic-mgmt` fixture builds its location as `https://<ip>:<port>`, so
the server terminates TLS with a self-signed certificate. This keeps the
fixture change smaller than teaching it to speak plain HTTP.

## 10. Configuration split

Two configuration systems, with a firm boundary.

**The JSON resource template** owns machine and resource facts: cores, NUMA
node, hugepages, mempool sizing, PCI addresses, and the mapping from OTG port
location strings to those addresses. It is static per host and is read by both
the container launcher and the control process.

**The OTG configuration** owns traffic: flows, rates, frame sizes, durations.
It is dynamic per test and arrives over REST.

Flow definitions must never migrate into the template. The moment they do,
there are two competing configuration systems and no clear source of truth.

The template is specified by `config/resources.schema.json`, with
`config/sonic-tb14.json` as the instance for the target host. It is read by
both the container launcher and the Python control process.

## 11. Port identity

`sonic-mgmt` names traffic generator ports `Card1/Port1` in its links CSV, and
`get_snappi_port_location` renders locations as `<chassis-ip>;<card>;<port>`.
Hand-written phase 1 scripts naturally want to name a PCI address directly.

Rather than force one convention, each port carries a `card` and `port` number
plus its `pci` address, and the server resolves all three location forms:

| Form | Example | Origin |
| ---- | ------- | ------ |
| `<ip>;<card>;<port>` | `100.117.29.53;1;1` | generated by `get_snappi_port_location` |
| `Card<N>/Port<M>` | `Card1/Port1` | the sonic-mgmt links CSV |
| PCI address | `0000:12:00.0` | direct, for phase 1 scripts |

This mapping is the source of truth; the links CSV follows it.

### 11.1 Derived values

Anything derivable is derived, so that two sources cannot disagree:

- Container `cpuset_cpus` comes from `resources.lcores`, and `cpuset_mems`
  from `resources.numa_node`.
- InfiniBand character devices come from
  `/sys/bus/pci/devices/<bdf>/infiniband_verbs/`. On the target host
  `0000:12:00.0` yields `uverbs0` and `0000:12:00.1` yields `uverbs1`.
- Port MAC addresses are read from the hardware at startup and are not
  configured, so they cannot drift.
- DPDK port indices come from array order: the first entry is port 0.

## 12. Stage acceptance criteria

**1a — standalone engine. Met.** Command-line driven, no REST. At a rate below
the ceiling, transmitted and received counts are equal with zero loss.
Unthrottled, transmit reaches at least the `testpmd` reference. Software
counters agree with hardware counters on both ports. `rx_unmatched` is zero.

Achieved: at 10% of line rate, 138,400 pps against 138,519 requested, so
pacing is accurate to within 0.1%, with all seven checks passing. Unthrottled,
1.336 Mpps and 96.4 Gbps with zero loss and no receive misses.

**1b — control plane and OTG subset. Met.** A hand-written snappi script
configures one flow, starts it, polls `get_metrics` until transmit reports
stopped, and observes equal transmit and receive counts, with the ports cabled
back to back.

Measured by `tests/b2b_flow.py` over ten seconds, in both directions of the
rate range: at 200,000 pps requested, 2,009,681 frames transmitted and
received with zero loss and pacing within 0.35%; unthrottled, 13,429,127
frames at 96.95 Gbps, again with zero loss. Byte counts agree exactly in both
runs, so the whole path from snappi through the REST subset, the command
socket, the data plane and back out through shared memory reports the same
numbers the engine measured for itself at stage 1a.

**1c — DUT.** The same flow through a real DUT with static destination MACs
and routed /31s. Static neighbours on the DUT are required because the
generator does not answer ARP. Acceptance is `tests/dut_flow.py` plus
`docs/phase1c-dut.md`.

Generator path **met** on sonic-tb14: `20.1.1.0` → `20.1.2.0` through the
DUT, 200,000 pps for 60 seconds, 11,992,486 frames transmitted and received
with zero loss (~14.4 Gbps on the wire). Flow counters match both port
hardware counters on the generator.

Full 1c sign-off adds optional `--dut-ingress-rx` and `--dut-egress-tx`
(from the DUT interface counters) and requires them to match generator
`frames_tx` and `frames_rx` within tolerance. Use `--require-dut-counters` in
CI once counter collection is automated.

**1d — container.** An image built from the JSON template, with
`/dev/infiniband` devices, `IPC_LOCK`, a hugepage mount, and cpuset pinning.
Acceptance on a DUT bench: `dut_flow.py` over the container API (see
`docs/phase1d-container.md`). `b2b_flow.py` applies only when the two ports are
looped.

**1e — sonic-mgmt integration.** Links CSV, connection graph entry, inventory
group, testbed entry, the `ext` selection hook, and a configurable API server
port. One test of our own passing under the standard pytest invocation.

## 13. Standing constraints

These are properties of the hardware and no later phase removes them.

- `rte_eth_dev_set_link_down` is unsupported on mlx5, so link state cannot be
  driven from DPDK. Tests calling `set_link_state` need out-of-band DUT
  control.
- Full-rate bidirectional traffic requires a second card in a separate PCIe
  slot.
- Small-frame line rate is unreachable: 64 byte frames at 100G need ~148 Mpps
  against ~8.7 Mpps per core and a card that tops out well below that.
- Only two ports exist, so the multi-port tests in `tests/snappi_tests/` are
  out of reach without more hardware.

## 14. Containing the traffic

The generator transmits at line rate, so a mistake is not something to detect
afterwards. Every check below decides before the first frame leaves, from
configuration and from the kernel's own state. None of them sends a test
packet: a test packet aimed at the wrong place has already done the damage it
was meant to detect.

**Which hardware can transmit.** EAL is given `-a` for each PCI address in the
resource template and nothing else, so no other device on the machine is even
probed. That reduces the question to whether the template names the right
devices, which `preflight.check_ports` answers from `/sys` before the engine
starts. A port may be driven only if the kernel is not using it: no IPv4 or
global IPv6 address, no routes, not enslaved to a bridge or bond, and not the
interface carrying the default route. This matters more than it appears,
because mlx5 is a bifurcated driver — the kernel keeps its netdev while DPDK
drives the same hardware — so putting a management port into promiscuous mode
would take that machine's own traffic away from the kernel.

**What may be transmitted.** `preflight.check_flow` runs on every flow during
`set_config`, before anything reaches the engine, and refuses frames that
could propagate past the link they leave on:

- Broadcast or multicast destination MAC, because a switch floods those to
  every port.
- A destination MAC belonging to any interface on this machine other than the
  generator's own ports.
- Source or destination IPv4 outside 10/8, 172.16/12, 192.168/16, the RFC 2544
  benchmarking range 198.18/15, or the three TEST-NET ranges, plus any extra
  prefixes listed in `engine.allowed_ipv4_subnets` in the resource template
  (for example the two /31s on a DUT bench). Default deny, so a typo cannot
  put an unlisted address on the wire.
- A destination that some interface on this machine claims through a specific
  route — the management subnet, `docker0`, `virbr0`. The default route is
  excluded from this test, since it matches everything; globally routable
  addresses are already refused by the rule above.

The unicast rule is also enforced in the engine's `CONFIGURE` handler, so it
holds for anything that can reach the command socket and not only for traffic
arriving through the REST API.

**What is not covered.** No software check can tell where a fibre goes. If a
port that passes every check above is physically cabled into a lab switch
instead of the device under test, the generator will send unicast frames to a
MAC that switch does not know, and it will flood them. The checks narrow this
to a single failure mode — correct device, wrong cable — and the frames are at
least non-routable and non-broadcast, but the control for it is physical.
Phase 1c connects a real DUT, and that is the point to confirm the cabling by
hand.

## 15. Exposure

The engine's control surfaces are local only: a Unix domain socket for
commands and a file in `/dev/shm` for counters. The REST API is the one
network listener, and it has no authentication, so the bind address is the
only thing limiting who can reach it.

While the snappi client runs on the generator itself, the server binds
`127.0.0.1` and nothing outside the box can reach it. Stage 1e moves the
client into the sonic-mgmt container, at which point the listener has to be
reachable from wherever that container runs, and TLS with a client
certificate becomes the mechanism rather than the bind address. The template
already carries the certificate paths for that.

One consequence of living on a lab machine is worth recording: a corporate
proxy in the environment applies to the generator's own address unless
`no_proxy` names it, because `requests` reads those variables for every URL.
`tests/b2b_flow.py` adds the API host to `no_proxy` itself rather than
relying on the shell, so a configuration is never handed to a proxy.

## 16. Open questions

- DPDK is pinned at 23.11 LTS, built from source. No decision yet on when that
  moves.
- Whether the container runs with host networking or a published port.
- Whether the stage 1e listener is reachable on the lab network with TLS and
  a client certificate, or stays on loopback with the container sharing the
  generator's network namespace.
