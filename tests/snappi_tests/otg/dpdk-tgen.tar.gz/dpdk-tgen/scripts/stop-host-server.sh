#!/bin/bash
# Stop bare-metal dpdk-tgen control server and engine (not the Docker container).

set -euo pipefail

sudo pkill -x dpdk-tgen-engine 2>/dev/null || true
sudo pkill -f "python3 -m dpdk_tgen.server" 2>/dev/null || true
sleep 1
