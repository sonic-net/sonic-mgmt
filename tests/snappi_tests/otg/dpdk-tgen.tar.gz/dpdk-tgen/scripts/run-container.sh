#!/bin/bash
# Start dpdk-tgen in Docker using the resource template.
#
#   ./scripts/run-container.sh config/sonic-tb14.json
#   ./scripts/run-container.sh --replace config/sonic-tb14.json

set -euo pipefail
cd "$(dirname "$0")/.."

REPLACE=()
if [[ "${1:-}" == "--replace" ]]; then
    REPLACE=(--replace)
    shift
fi

RESOURCES="${1:-config/sonic-tb14.json}"
export PYTHONPATH="${PYTHONPATH:-}:$(pwd)/control"
exec python3 -m dpdk_tgen.launcher --resources "$RESOURCES" run "${REPLACE[@]}"
