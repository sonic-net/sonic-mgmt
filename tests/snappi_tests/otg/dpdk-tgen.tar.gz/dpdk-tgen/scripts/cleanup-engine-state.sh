#!/bin/bash
# Remove stale dpdk-tgen hugepage maps and IPC files after the engine has stopped.
# Safe to run when no dpdk-tgen-engine / dpdk_tgen.server process is active.

set -euo pipefail

if pgrep -x dpdk-tgen-engine >/dev/null \
    || pgrep -f "python3 -m dpdk_tgen.server" >/dev/null; then
    echo "error: dpdk-tgen is still running" >&2
    exit 1
fi

sudo rm -f /dev/hugepages/tgenmap_* /var/run/dpdk-tgen.sock /dev/shm/dpdk-tgen-stats
sudo rm -rf /var/run/dpdk/tgen 2>/dev/null || true
echo "cleaned dpdk-tgen engine state on the host"
