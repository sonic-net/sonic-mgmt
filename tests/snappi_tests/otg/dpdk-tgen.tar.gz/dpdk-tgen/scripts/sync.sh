#!/bin/bash
# Push the working tree to the traffic generator host and build it there.
#
# The repository lives on the workstation, but the engine only compiles and
# runs where the NIC is.

set -euo pipefail

HOST=${TGEN_HOST:-100.117.29.53}
USER=${TGEN_USER:-ansible}
DEST=${TGEN_DEST:-dpdk-tgen}
KEY=${TGEN_KEY:-$HOME/.ssh/id_ed25519_dpdk_tgen}

cd "$(dirname "$0")/.."

rsync -az --delete \
	--exclude build/ \
	--exclude .git/ \
	--exclude .venv/ \
	--exclude __pycache__/ \
	-e "ssh -i $KEY -o BatchMode=yes -o StrictHostKeyChecking=no" \
	./ "$USER@$HOST:$DEST/"

echo "synced to $USER@$HOST:$DEST"

if [ "${1:-}" = "--build" ]; then
	ssh -i "$KEY" -o BatchMode=yes -o StrictHostKeyChecking=no \
		"$USER@$HOST" "cd $DEST && make -j\$(nproc)"
fi
