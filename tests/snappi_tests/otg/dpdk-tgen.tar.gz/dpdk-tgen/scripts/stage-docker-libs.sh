#!/bin/bash
# Copy shared libraries required by build/dpdk-tgen-engine into docker/vendor/lib
# and the mlx5 net PMD into docker/vendor/dpdk, matching the host DPDK build.

set -euo pipefail
cd "$(dirname "$0")/.."

ENGINE="${ENGINE:-build/dpdk-tgen-engine}"
DEST="docker/vendor/lib"
PMD_DEST="docker/vendor/dpdk"
DPDK_LIB="${DPDK_LIB:-/usr/local/lib/x86_64-linux-gnu}"
PMD_SRC="${DPDK_LIB}/dpdk/pmds-24.0"

# Installed next to librte_eal (not loaded via the pmds plugin scan).
FLAT_DPDK_LIBS=(
    librte_bus_pci
    librte_bus_vdev
    librte_bus_auxiliary
    librte_pci
    librte_common_mlx5
    librte_hash
    librte_rcu
)

# Loaded from pmds-24.0; bus drivers live in $DEST only.
PMD_PLUGINS=(
    librte_net_mlx5
    librte_mempool_ring
)

if [[ ! -x "$ENGINE" ]]; then
    echo "error: $ENGINE not found; run make first" >&2
    exit 1
fi

mkdir -p "$DEST"
rm -f "$DEST"/*

copy_lib() {
    local path="$1"
    [[ -f "$path" ]] || return 0
    local base
    base="$(basename "$path")"
    cp -L "$path" "$DEST/$base"
}

stage_ldd_tree() {
    local binary="$1"
    while IFS= read -r lib; do
        copy_lib "$lib"
    done < <(ldd "$binary" 2>/dev/null | awk '/=> \/usr\/local/ {print $3}' | sort -u)
}

stage_ldd_tree "$ENGINE"

for base in "${FLAT_DPDK_LIBS[@]}"; do
    shopt -s nullglob
    for so in "$DPDK_LIB/${base}.so"*; do
        copy_lib "$so"
    done
    shopt -u nullglob
done

if [[ ! -d "$PMD_SRC" ]]; then
    echo "error: DPDK PMD directory not found: $PMD_SRC" >&2
    exit 1
fi

rm -rf "$PMD_DEST"
PMD_OUT="${PMD_DEST}/pmds-24.0"
mkdir -p "$PMD_OUT"

shopt -s nullglob
for base in "${PMD_PLUGINS[@]}"; do
    for so in "$PMD_SRC/${base}.so"*; do
        cp -a "$so" "$PMD_OUT/"
        stage_ldd_tree "$so"
    done
done
shopt -u nullglob

lib_count="$(find "$DEST" -maxdepth 1 -type f | wc -l)"
pmd_count="$(find "$PMD_OUT" -maxdepth 1 -type f | wc -l)"
echo "staged $lib_count libraries under $DEST"
echo "staged $pmd_count PMD files under $PMD_OUT"
