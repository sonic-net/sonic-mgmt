// Command socket. A line-oriented text protocol over a Unix domain socket,
// spoken by the Python control process.
//
// Deliberately not JSON: the command surface is seven verbs, and a parser
// would be larger than the thing it parses. Python owns all JSON. If this
// surface outgrows the format, vendor a JSON library rather than extending
// the ad-hoc parser.

#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "port.hpp"
#include "tgen.hpp"

namespace tgen {

struct EngineContext {
	Engine* engine = nullptr;
	std::vector<Port*> ports;
	std::uint64_t duration_ms = 0;
	std::uint64_t stop_at_tsc = 0;  // 0 means transmit until told to stop
};

class CommandServer {
public:
	CommandServer(EngineContext& ctx, const std::string& path);
	~CommandServer();

	CommandServer(const CommandServer&) = delete;
	CommandServer& operator=(const CommandServer&) = delete;

	// Services at most one client interaction. Returns false once the
	// client has asked the engine to exit.
	bool poll_once(int timeout_ms);

private:
	std::string dispatch(const std::string& line);
	std::string cmd_configure(const std::vector<std::string>& tokens);
	std::string cmd_start();
	std::string cmd_stop();
	std::string cmd_reset();
	std::string cmd_ports() const;
	std::string cmd_status() const;

	EngineContext& ctx_;
	std::string path_;
	int listen_fd_ = -1;
	int conn_fd_ = -1;
	std::string rxbuf_;
	bool running_ = true;
};

}  // namespace tgen
