// Header template construction. Built once per flow, copied per packet.

#include <netinet/in.h>

#include <cstring>

#include <rte_byteorder.h>
#include <rte_ip.h>
#include <rte_udp.h>

#include "tgen.hpp"

namespace tgen {

void
build_header(FlowConfig& flow, const rte_ether_addr& src_mac,
	     const rte_ether_addr& dst_mac, std::uint32_t src_ip,
	     std::uint32_t dst_ip, std::uint16_t src_port,
	     std::uint16_t dst_port)
{
	std::memset(flow.hdr, 0, sizeof(flow.hdr));

	auto* eth = reinterpret_cast<rte_ether_hdr*>(flow.hdr);
	auto* ip = reinterpret_cast<rte_ipv4_hdr*>(flow.hdr + sizeof(rte_ether_hdr));
	auto* udp = reinterpret_cast<rte_udp_hdr*>(
		reinterpret_cast<std::uint8_t*>(ip) + sizeof(rte_ipv4_hdr));

	rte_ether_addr_copy(&src_mac, &eth->src_addr);
	rte_ether_addr_copy(&dst_mac, &eth->dst_addr);
	eth->ether_type = rte_cpu_to_be_16(RTE_ETHER_TYPE_IPV4);

	ip->version_ihl = RTE_IPV4_VHL_DEF;
	ip->total_length = rte_cpu_to_be_16(
		static_cast<std::uint16_t>(flow.frame_size - sizeof(rte_ether_hdr)));
	ip->time_to_live = 64;
	ip->next_proto_id = IPPROTO_UDP;
	ip->src_addr = rte_cpu_to_be_32(src_ip);
	ip->dst_addr = rte_cpu_to_be_32(dst_ip);

	// No field in the IPv4 header varies per packet, so the checksum is
	// computed once here and never touched in the fast path.
	ip->hdr_checksum = 0;
	ip->hdr_checksum = rte_ipv4_cksum(ip);

	udp->src_port = rte_cpu_to_be_16(src_port);
	udp->dst_port = rte_cpu_to_be_16(dst_port);
	udp->dgram_len = rte_cpu_to_be_16(static_cast<std::uint16_t>(
		flow.frame_size - sizeof(rte_ether_hdr) - sizeof(rte_ipv4_hdr)));

	// Zero is a valid UDP checksum over IPv4.
	udp->dgram_cksum = 0;
}

}  // namespace tgen
