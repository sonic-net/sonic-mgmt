#include "shm.hpp"

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>
#include <stdexcept>

namespace tgen {

Shm::Shm(const std::string& path) : path_(path)
{
	fd_ = ::open(path.c_str(), O_CREAT | O_RDWR | O_TRUNC, 0644);
	if (fd_ < 0)
		throw std::runtime_error("open " + path + ": " +
					 std::strerror(errno));

	if (::ftruncate(fd_, sizeof(ShmRegion)) != 0) {
		const int e = errno;
		::close(fd_);
		fd_ = -1;
		throw std::runtime_error("ftruncate " + path + ": " +
					 std::strerror(e));
	}

	void* p = ::mmap(nullptr, sizeof(ShmRegion), PROT_READ | PROT_WRITE,
			 MAP_SHARED, fd_, 0);
	if (p == MAP_FAILED) {
		const int e = errno;
		::close(fd_);
		fd_ = -1;
		throw std::runtime_error("mmap " + path + ": " +
					 std::strerror(e));
	}

	region_ = static_cast<ShmRegion*>(p);
	std::memset(region_, 0, sizeof(ShmRegion));

	region_->header.magic = kShmMagic;
	region_->header.layout_version = kShmVersion;
	region_->header.engine_state = kStateInit;
}

Shm::~Shm()
{
	if (region_ != nullptr)
		::munmap(region_, sizeof(ShmRegion));
	if (fd_ >= 0)
		::close(fd_);
}

}  // namespace tgen
