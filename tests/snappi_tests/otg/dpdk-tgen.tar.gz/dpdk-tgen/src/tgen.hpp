// dpdk-tgen phase 1a: shared types.
//
// Everything placed in the shared memory region is standard-layout POD with a
// statically asserted size and offset, because the Python control process
// reads the same bytes with struct.unpack. If a static_assert here fires, the
// Python side must change in lockstep.

#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>

#include <rte_common.h>
#include <rte_ether.h>
#include <rte_mempool.h>

namespace tgen {

inline constexpr std::uint16_t kMaxFlows = 16;
inline constexpr std::uint16_t kMaxPorts = 8;
inline constexpr std::uint16_t kMaxLcores = 128;
inline constexpr std::uint16_t kTxBurst = 32;
inline constexpr std::uint16_t kRxBurst = 32;

// ethernet(14) + ipv4(20) + udp(8)
inline constexpr std::uint16_t kHdrLen = 42;

inline constexpr std::uint32_t kSigMagic = 0x54474e31u;  // "TGN1"
inline constexpr std::uint32_t kShmMagic = 0x5447534du;  // "TGSM"
inline constexpr std::uint32_t kShmVersion = 1;

// Written at a fixed offset immediately after the UDP header so the receive
// path is one load and one compare rather than a header walk.
//
// flow_id, seq and tx_tsc are unused in phase 1a. They exist so that multiple
// flows, loss detection and latency are additive later rather than a rewrite
// of the receive path and the wire format.
struct Signature {
	std::uint32_t magic;     // network order
	std::uint16_t flow_id;   // network order
	std::uint16_t reserved;
	std::uint64_t seq;       // network order
	std::uint64_t tx_tsc;    // rte_rdtsc at transmit, network order
} __rte_packed;

static_assert(sizeof(Signature) == 24, "signature is 24 bytes on the wire");

inline constexpr std::uint16_t kMinFrame =
	kHdrLen + static_cast<std::uint16_t>(sizeof(Signature));  // 66

// ---------------------------------------------------------------------------
// Shared memory layout
// ---------------------------------------------------------------------------

struct ShmHeader {
	std::uint32_t magic;
	std::uint32_t layout_version;
	std::uint32_t nb_lcores;
	std::uint32_t nb_flows;
	std::uint32_t nb_ports;
	std::uint32_t engine_state;  // see EngineState
	std::uint64_t tsc_hz;
	std::uint64_t start_tsc;
};

enum EngineState : std::uint32_t {
	kStateInit = 0,
	kStateReady = 1,
	kStateRunning = 2,
	kStateStopping = 3,
	kStateError = 4,
};

struct FlowCounters {
	std::uint64_t tx_pkts;
	std::uint64_t tx_bytes;
	std::uint64_t tx_fail;
	std::uint64_t rx_pkts;
	std::uint64_t rx_bytes;
};

// One block per lcore, cache aligned so that lcores never share a line. Each
// block is written only by its owning lcore, which is why no locks or atomics
// appear in the fast path.
struct LcoreBlock {
	FlowCounters flow[kMaxFlows];
	std::uint64_t rx_unmatched;
	std::uint64_t tx_alloc_fail;
} __rte_cache_aligned;

// Mirrors the subset of rte_eth_stats we reconcile against.
struct PortHwCounters {
	std::uint64_t opackets;
	std::uint64_t obytes;
	std::uint64_t ipackets;
	std::uint64_t ibytes;
	std::uint64_t imissed;
	std::uint64_t ierrors;
	std::uint64_t oerrors;
	std::uint64_t rx_nombuf;
};

struct ShmRegion {
	ShmHeader header;
	PortHwCounters port[kMaxPorts];
	LcoreBlock lcore[kMaxLcores];
};

static_assert(sizeof(ShmHeader) == 40, "shm header layout");
static_assert(sizeof(FlowCounters) == 40, "flow counter layout");
static_assert(sizeof(PortHwCounters) == 64, "port counter layout");
static_assert(sizeof(LcoreBlock) == 704, "lcore block layout");
static_assert(offsetof(ShmRegion, port) == 40, "port array offset");
static_assert(offsetof(ShmRegion, lcore) == 576, "lcore array offset");
static_assert(RTE_MAX_LCORE <= kMaxLcores, "lcore block array too small");

// ---------------------------------------------------------------------------
// Engine state (process local, not shared)
// ---------------------------------------------------------------------------

struct FlowConfig {
	std::uint16_t flow_id;
	std::uint16_t tx_port;
	std::uint16_t rx_port;
	std::uint16_t frame_size;  // ethernet frame length, excluding FCS
	std::uint64_t rate_pps;    // 0 means unthrottled
	std::uint8_t hdr[kHdrLen];
};

struct Engine {
	ShmRegion* shm = nullptr;
	rte_mempool* pool = nullptr;
	FlowConfig flows[kMaxFlows] = {};
	// Written by the control thread, read by the transmit worker every
	// iteration, so it cannot be a plain integer.
	std::atomic<std::uint16_t> nb_flows{0};
	std::atomic<bool> force_quit{false};
	std::atomic<bool> tx_enabled{false};
};

struct WorkerArgs {
	Engine* engine;
	std::uint16_t port;  // receive workers only
};

// Bytes each frame occupies on the wire beyond its own length: 4 FCS,
// 8 preamble and start-of-frame delimiter, 12 inter-frame gap. Every
// percentage-of-line-rate conversion goes through this one constant.
inline constexpr std::uint16_t kWireOverhead = 24;

void build_header(FlowConfig& flow, const rte_ether_addr& src_mac,
		  const rte_ether_addr& dst_mac, std::uint32_t src_ip,
		  std::uint32_t dst_ip, std::uint16_t src_port,
		  std::uint16_t dst_port);

int tx_worker(void* arg);
int rx_worker(void* arg);

}  // namespace tgen
