#include "cmdserver.hpp"

#include <arpa/inet.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#include <cerrno>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <stdexcept>
#include <unordered_map>

#include <rte_cycles.h>
#include <rte_ethdev.h>

namespace tgen {
namespace {

std::vector<std::string>
tokenize(const std::string& line)
{
	std::vector<std::string> out;
	std::istringstream is(line);
	std::string tok;
	while (is >> tok)
		out.push_back(tok);
	return out;
}

std::unordered_map<std::string, std::string>
key_values(const std::vector<std::string>& tokens, std::size_t from)
{
	std::unordered_map<std::string, std::string> kv;
	for (std::size_t i = from; i < tokens.size(); i++) {
		const auto eq = tokens[i].find('=');
		if (eq != std::string::npos)
			kv[tokens[i].substr(0, eq)] = tokens[i].substr(eq + 1);
	}
	return kv;
}

std::uint64_t
get_u64(const std::unordered_map<std::string, std::string>& kv,
	const std::string& key, std::uint64_t def)
{
	const auto it = kv.find(key);
	return it == kv.end() ? def : std::strtoull(it->second.c_str(), nullptr, 10);
}

std::string
mac_string(const rte_ether_addr& a)
{
	char buf[RTE_ETHER_ADDR_FMT_SIZE];
	rte_ether_format_addr(buf, sizeof(buf), &a);
	return std::string(buf);
}

}  // namespace

CommandServer::CommandServer(EngineContext& ctx, const std::string& path)
	: ctx_(ctx), path_(path)
{
	::unlink(path.c_str());

	listen_fd_ = ::socket(AF_UNIX, SOCK_STREAM, 0);
	if (listen_fd_ < 0)
		throw std::runtime_error(std::string("socket: ") + std::strerror(errno));

	sockaddr_un addr;
	std::memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	if (path.size() >= sizeof(addr.sun_path))
		throw std::runtime_error("socket path too long: " + path);
	std::strncpy(addr.sun_path, path.c_str(), sizeof(addr.sun_path) - 1);

	if (::bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0)
		throw std::runtime_error("bind " + path + ": " + std::strerror(errno));
	if (::listen(listen_fd_, 1) != 0)
		throw std::runtime_error(std::string("listen: ") + std::strerror(errno));

	// The control process may run as a different user inside the container.
	::chmod(path.c_str(), 0666);
}

CommandServer::~CommandServer()
{
	if (conn_fd_ >= 0)
		::close(conn_fd_);
	if (listen_fd_ >= 0)
		::close(listen_fd_);
	::unlink(path_.c_str());
}

bool
CommandServer::poll_once(int timeout_ms)
{
	pollfd fds[2];
	int nfds = 0;

	fds[nfds].fd = listen_fd_;
	fds[nfds].events = POLLIN;
	fds[nfds].revents = 0;
	nfds++;

	if (conn_fd_ >= 0) {
		fds[nfds].fd = conn_fd_;
		fds[nfds].events = POLLIN;
		fds[nfds].revents = 0;
		nfds++;
	}

	const int rc = ::poll(fds, nfds, timeout_ms);
	if (rc <= 0)
		return running_;

	if ((fds[0].revents & POLLIN) != 0) {
		const int fd = ::accept(listen_fd_, nullptr, nullptr);
		if (fd >= 0) {
			// One controller at a time; a second connection
			// replaces the first rather than queueing behind it.
			if (conn_fd_ >= 0)
				::close(conn_fd_);
			conn_fd_ = fd;
			rxbuf_.clear();
		}
	}

	if (nfds > 1 && (fds[1].revents & (POLLIN | POLLHUP)) != 0) {
		char buf[1024];
		const ssize_t n = ::read(conn_fd_, buf, sizeof(buf));
		if (n <= 0) {
			::close(conn_fd_);
			conn_fd_ = -1;
			return running_;
		}

		rxbuf_.append(buf, static_cast<std::size_t>(n));

		std::size_t nl;
		while ((nl = rxbuf_.find('\n')) != std::string::npos) {
			const std::string line = rxbuf_.substr(0, nl);
			rxbuf_.erase(0, nl + 1);

			std::string reply = dispatch(line);
			reply.push_back('\n');
			if (::write(conn_fd_, reply.data(), reply.size()) < 0) {
				::close(conn_fd_);
				conn_fd_ = -1;
				break;
			}
		}
	}

	return running_;
}

std::string
CommandServer::dispatch(const std::string& line)
{
	const auto tokens = tokenize(line);
	if (tokens.empty())
		return "ERR empty command";

	const std::string& verb = tokens[0];

	if (verb == "PING")
		return "OK";
	if (verb == "PORTS")
		return cmd_ports();
	if (verb == "STATUS")
		return cmd_status();
	if (verb == "CONFIGURE")
		return cmd_configure(tokens);
	if (verb == "START")
		return cmd_start();
	if (verb == "STOP")
		return cmd_stop();
	if (verb == "RESET")
		return cmd_reset();
	if (verb == "QUIT") {
		cmd_stop();
		running_ = false;
		return "OK";
	}

	return "ERR unknown command " + verb;
}

std::string
CommandServer::cmd_configure(const std::vector<std::string>& tokens)
{
	Engine& eng = *ctx_.engine;

	if (eng.shm->header.engine_state == kStateRunning)
		return "ERR cannot configure while running";

	const auto kv = key_values(tokens, 1);

	const auto flow_id = static_cast<std::uint16_t>(get_u64(kv, "flow_id", 0));
	if (flow_id >= kMaxFlows)
		return "ERR flow_id out of range";

	const auto tx_port = static_cast<std::uint16_t>(get_u64(kv, "tx_port", 0));
	const auto rx_port = static_cast<std::uint16_t>(get_u64(kv, "rx_port", 1));
	if (tx_port >= ctx_.ports.size() || rx_port >= ctx_.ports.size())
		return "ERR port index out of range";

	const auto frame_size = static_cast<std::uint16_t>(get_u64(kv, "frame_size", 9000));
	if (frame_size < kMinFrame)
		return "ERR frame_size below " + std::to_string(kMinFrame);

	FlowConfig& flow = eng.flows[flow_id];
	flow.flow_id = flow_id;
	flow.tx_port = tx_port;
	flow.rx_port = rx_port;
	flow.frame_size = frame_size;
	flow.rate_pps = get_u64(kv, "rate_pps", 0);

	rte_ether_addr src_mac = ctx_.ports[tx_port]->mac();
	rte_ether_addr dst_mac = ctx_.ports[rx_port]->mac();
	if (kv.count("src_mac") != 0 &&
	    rte_ether_unformat_addr(kv.at("src_mac").c_str(), &src_mac) != 0)
		return "ERR bad src_mac";
	if (kv.count("dst_mac") != 0 &&
	    rte_ether_unformat_addr(kv.at("dst_mac").c_str(), &dst_mac) != 0)
		return "ERR bad dst_mac";

	// A switch floods broadcast and multicast to every port, so a frame
	// addressed that way escapes the link it was sent on. The control
	// process rejects these too, but the invariant belongs here as well:
	// nothing that can reach the command socket may bypass it.
	if (rte_is_multicast_ether_addr(&dst_mac))
		return "ERR dst_mac must be unicast, refusing broadcast or multicast";
	if (rte_is_zero_ether_addr(&dst_mac))
		return "ERR dst_mac must not be all zeros";

	in_addr sip{};
	in_addr dip{};
	const std::string src_ip = kv.count("src_ip") ? kv.at("src_ip") : "10.0.0.1";
	const std::string dst_ip = kv.count("dst_ip") ? kv.at("dst_ip") : "10.0.0.2";
	if (inet_pton(AF_INET, src_ip.c_str(), &sip) != 1)
		return "ERR bad src_ip";
	if (inet_pton(AF_INET, dst_ip.c_str(), &dip) != 1)
		return "ERR bad dst_ip";

	build_header(flow, src_mac, dst_mac, rte_be_to_cpu_32(sip.s_addr),
		     rte_be_to_cpu_32(dip.s_addr),
		     static_cast<std::uint16_t>(get_u64(kv, "src_l4", 5001)),
		     static_cast<std::uint16_t>(get_u64(kv, "dst_l4", 5002)));

	ctx_.duration_ms = get_u64(kv, "duration_ms", 0);

	if (flow_id + 1 > eng.nb_flows.load(std::memory_order_relaxed))
		eng.nb_flows.store(static_cast<std::uint16_t>(flow_id + 1),
				   std::memory_order_relaxed);
	eng.shm->header.nb_flows = eng.nb_flows.load(std::memory_order_relaxed);

	return "OK";
}

std::string
CommandServer::cmd_start()
{
	Engine& eng = *ctx_.engine;

	if (eng.nb_flows.load(std::memory_order_relaxed) == 0)
		return "ERR no flow configured";
	if (eng.shm->header.engine_state == kStateRunning)
		return "OK already running";

	ctx_.stop_at_tsc = 0;
	if (ctx_.duration_ms != 0)
		ctx_.stop_at_tsc =
			rte_rdtsc() + (rte_get_tsc_hz() * ctx_.duration_ms) / 1000;

	eng.shm->header.start_tsc = rte_rdtsc();
	eng.shm->header.engine_state = kStateRunning;
	eng.tx_enabled.store(true, std::memory_order_relaxed);

	return "OK";
}

std::string
CommandServer::cmd_stop()
{
	Engine& eng = *ctx_.engine;

	eng.tx_enabled.store(false, std::memory_order_relaxed);
	ctx_.stop_at_tsc = 0;

	// Let the transmit worker leave the flow loop before anything is
	// allowed to mutate flow configuration, and let the last packets
	// arrive before counters are read.
	::usleep(200000);

	eng.shm->header.engine_state = kStateReady;
	return "OK";
}

std::string
CommandServer::cmd_reset()
{
	Engine& eng = *ctx_.engine;

	if (eng.shm->header.engine_state == kStateRunning)
		return "ERR cannot reset while running";

	for (std::uint16_t i = 0; i < kMaxLcores; i++)
		std::memset(&eng.shm->lcore[i], 0, sizeof(LcoreBlock));
	for (std::uint16_t i = 0; i < kMaxPorts; i++)
		std::memset(&eng.shm->port[i], 0, sizeof(PortHwCounters));

	// Hardware counters are cumulative from port start, so they have to be
	// cleared too or reconciliation compares different epochs.
	for (Port* p : ctx_.ports)
		rte_eth_stats_reset(p->id());

	return "OK";
}

std::string
CommandServer::cmd_ports() const
{
	std::ostringstream os;
	os << "OK nb_ports=" << ctx_.ports.size();
	for (std::size_t i = 0; i < ctx_.ports.size(); i++) {
		os << " p" << i << ".id=" << ctx_.ports[i]->id()
		   << " p" << i << ".mac=" << mac_string(ctx_.ports[i]->mac())
		   << " p" << i << ".speed=" << ctx_.ports[i]->speed_mbps();
	}
	return os.str();
}

std::string
CommandServer::cmd_status() const
{
	const Engine& eng = *ctx_.engine;
	const char* state = "unknown";

	switch (eng.shm->header.engine_state) {
	case kStateInit: state = "init"; break;
	case kStateReady: state = "ready"; break;
	case kStateRunning: state = "running"; break;
	case kStateStopping: state = "stopping"; break;
	case kStateError: state = "error"; break;
	default: break;
	}

	std::ostringstream os;
	os << "OK state=" << state
	   << " flows=" << eng.nb_flows.load(std::memory_order_relaxed)
	   << " ports=" << ctx_.ports.size();
	return os.str();
}

}  // namespace tgen
