// Port lifetime. Configures and starts on construction, stops and closes on
// destruction, so an exception anywhere in setup leaves no port running.

#pragma once

#include <cstdint>

#include <rte_ethdev.h>
#include <rte_mempool.h>

namespace tgen {

class Port {
public:
	Port(std::uint16_t id, rte_mempool* pool, std::uint16_t mtu);
	~Port();

	Port(const Port&) = delete;
	Port& operator=(const Port&) = delete;
	Port(Port&&) = delete;
	Port& operator=(Port&&) = delete;

	std::uint16_t id() const { return id_; }
	const rte_ether_addr& mac() const { return mac_; }

	// Blocks until the link reports up, or throws on timeout.
	void wait_link_up(int timeout_s);

	// Valid only after wait_link_up.
	std::uint32_t speed_mbps() const { return speed_mbps_; }

	void hw_counters(struct PortHwCounters& out) const;

private:
	std::uint16_t id_;
	bool started_ = false;
	rte_ether_addr mac_{};
	std::uint32_t speed_mbps_ = 0;
};

}  // namespace tgen
