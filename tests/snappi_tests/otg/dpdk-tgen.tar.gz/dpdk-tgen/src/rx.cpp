// Receive worker: match the signature, attribute the packet to its flow.

#include <rte_branch_prediction.h>
#include <rte_byteorder.h>
#include <rte_cycles.h>
#include <rte_ethdev.h>
#include <rte_mbuf.h>

#include "tgen.hpp"

namespace tgen {

int
rx_worker(void* arg)
{
	auto* args = static_cast<WorkerArgs*>(arg);
	Engine& eng = *args->engine;
	const std::uint16_t port = args->port;
	LcoreBlock& block = eng.shm->lcore[rte_lcore_id()];

	const std::uint32_t magic = rte_cpu_to_be_32(kSigMagic);
	rte_mbuf* bufs[kRxBurst];

	while (!eng.force_quit.load(std::memory_order_relaxed)) {
		const std::uint16_t n = rte_eth_rx_burst(port, 0, bufs, kRxBurst);

		if (n == 0) {
			rte_pause();
			continue;
		}

		for (std::uint16_t i = 0; i < n; i++) {
			rte_mbuf* m = bufs[i];
			bool matched = false;

			if (likely(m->data_len >= kMinFrame)) {
				const auto* sig = rte_pktmbuf_mtod_offset(
					m, const Signature*, kHdrLen);

				if (likely(sig->magic == magic)) {
					const std::uint16_t fid =
						rte_be_to_cpu_16(sig->flow_id);

					if (likely(fid < kMaxFlows)) {
						FlowCounters& c = block.flow[fid];
						c.rx_pkts++;
						c.rx_bytes += m->pkt_len;
						matched = true;
					}
				}
			}

			// Anything without our signature is counted separately
			// rather than attributed to a flow. On a back-to-back
			// or DUT setup this should stay at zero; a non-zero
			// value means something else is on the wire.
			if (unlikely(!matched))
				block.rx_unmatched++;

			rte_pktmbuf_free(m);
		}
	}

	return 0;
}

}  // namespace tgen
