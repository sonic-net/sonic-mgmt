// Transmit worker: token bucket pacing, header copy, signature stamp.

#include <cstring>

#include <rte_branch_prediction.h>
#include <rte_cycles.h>
#include <rte_ethdev.h>
#include <rte_memcpy.h>
#include <rte_mbuf.h>

#include "tgen.hpp"

namespace tgen {
namespace {

struct TxState {
	std::uint64_t tokens = 0;
	std::uint64_t last_tsc = 0;
	std::uint64_t seq = 0;
};

}  // namespace

int
tx_worker(void* arg)
{
	auto* args = static_cast<WorkerArgs*>(arg);
	Engine& eng = *args->engine;
	LcoreBlock& block = eng.shm->lcore[rte_lcore_id()];

	const std::uint64_t hz = rte_get_tsc_hz();
	TxState state[kMaxFlows];
	rte_mbuf* bufs[kTxBurst];

	for (std::uint16_t i = 0; i < kMaxFlows; i++)
		state[i].last_tsc = rte_rdtsc();

	while (!eng.force_quit.load(std::memory_order_relaxed)) {
		if (!eng.tx_enabled.load(std::memory_order_relaxed)) {
			rte_pause();
			continue;
		}

		const std::uint16_t nb_flows =
			eng.nb_flows.load(std::memory_order_relaxed);

		for (std::uint16_t i = 0; i < nb_flows; i++) {
			FlowConfig& flow = eng.flows[i];
			TxState& st = state[i];
			std::uint16_t nb;

			if (flow.rate_pps != 0) {
				const std::uint64_t now = rte_rdtsc();
				std::uint64_t elapsed = now - st.last_tsc;

				// Clamp so the multiply below cannot overflow
				// after a long pause.
				if (elapsed > hz)
					elapsed = hz;

				const std::uint64_t gained =
					(elapsed * flow.rate_pps) / hz;

				// Advance the clock only when a whole token was
				// earned, otherwise the fractional remainder is
				// discarded every iteration and the achieved
				// rate drifts low.
				if (gained != 0) {
					st.tokens += gained;
					st.last_tsc = now;
				}

				// Cap at one burst so that re-enabling transmit
				// does not release a backlog.
				if (st.tokens > kTxBurst)
					st.tokens = kTxBurst;
				if (st.tokens == 0)
					continue;

				nb = static_cast<std::uint16_t>(st.tokens);
			} else {
				nb = kTxBurst;
			}

			if (unlikely(rte_pktmbuf_alloc_bulk(eng.pool, bufs, nb) != 0)) {
				block.tx_alloc_fail++;
				continue;
			}

			for (std::uint16_t j = 0; j < nb; j++) {
				rte_mbuf* m = bufs[j];
				auto* p = rte_pktmbuf_mtod(m, std::uint8_t*);

				rte_memcpy(p, flow.hdr, kHdrLen);

				auto* sig = reinterpret_cast<Signature*>(p + kHdrLen);
				sig->magic = rte_cpu_to_be_32(kSigMagic);
				sig->flow_id = rte_cpu_to_be_16(flow.flow_id);
				sig->reserved = 0;
				sig->seq = rte_cpu_to_be_64(st.seq++);
				sig->tx_tsc = rte_cpu_to_be_64(rte_rdtsc());

				// The remaining bytes are left as they were.
				// Payload contents are not significant, and
				// copying a 9000 byte template at line rate
				// would cost 11.6 GB/s of memory bandwidth for
				// nothing.
				m->pkt_len = flow.frame_size;
				m->data_len = flow.frame_size;
			}

			const std::uint16_t sent =
				rte_eth_tx_burst(flow.tx_port, 0, bufs, nb);

			FlowCounters& c = block.flow[flow.flow_id];
			c.tx_pkts += sent;
			c.tx_bytes += static_cast<std::uint64_t>(sent) * flow.frame_size;

			if (unlikely(sent < nb)) {
				c.tx_fail += nb - sent;
				for (std::uint16_t j = sent; j < nb; j++)
					rte_pktmbuf_free(bufs[j]);

				// Rewind so the transmitted sequence space has
				// no gaps. Gaps would later be indistinguishable
				// from real loss.
				st.seq -= nb - sent;
			}

			// Only packets the NIC accepted consume tokens.
			if (flow.rate_pps != 0)
				st.tokens -= sent;
		}
	}

	return 0;
}

}  // namespace tgen
