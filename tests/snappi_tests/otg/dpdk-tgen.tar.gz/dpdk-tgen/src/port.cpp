#include "port.hpp"

#include <unistd.h>

#include <cstring>
#include <stdexcept>
#include <string>

#include "tgen.hpp"

namespace tgen {
namespace {

// Measured on the target hardware: a second queue and deeper rings made no
// difference at 9000 bytes, because the limit is PCIe rather than descriptors.
constexpr std::uint16_t kRxDesc = 1024;
constexpr std::uint16_t kTxDesc = 1024;

std::string
err(const std::string& what, std::uint16_t id, int rc)
{
	return what + " failed on port " + std::to_string(id) + ": " +
	       rte_strerror(-rc) + " (" + std::to_string(rc) + ")";
}

}  // namespace

Port::Port(std::uint16_t id, rte_mempool* pool, std::uint16_t mtu) : id_(id)
{
	rte_eth_dev_info info;
	std::memset(&info, 0, sizeof(info));

	int rc = rte_eth_dev_info_get(id, &info);
	if (rc != 0)
		throw std::runtime_error(err("rte_eth_dev_info_get", id, rc));

	rte_eth_conf conf;
	std::memset(&conf, 0, sizeof(conf));
	conf.rxmode.mtu = mtu;

	// Valid here because every mbuf comes from a single pool and is never
	// shared, so the driver can return buffers without checking refcounts.
	if (info.tx_offload_capa & RTE_ETH_TX_OFFLOAD_MBUF_FAST_FREE)
		conf.txmode.offloads |= RTE_ETH_TX_OFFLOAD_MBUF_FAST_FREE;

	rc = rte_eth_dev_configure(id, 1, 1, &conf);
	if (rc != 0)
		throw std::runtime_error(err("rte_eth_dev_configure", id, rc));

	std::uint16_t nb_rxd = kRxDesc;
	std::uint16_t nb_txd = kTxDesc;
	rc = rte_eth_dev_adjust_nb_rx_tx_desc(id, &nb_rxd, &nb_txd);
	if (rc != 0)
		throw std::runtime_error(err("adjust_nb_rx_tx_desc", id, rc));

	int socket = rte_eth_dev_socket_id(id);
	if (socket < 0)
		socket = static_cast<int>(rte_socket_id());

	rte_eth_rxconf rxconf = info.default_rxconf;
	rc = rte_eth_rx_queue_setup(id, 0, nb_rxd, static_cast<unsigned>(socket),
				    &rxconf, pool);
	if (rc != 0)
		throw std::runtime_error(err("rte_eth_rx_queue_setup", id, rc));

	rte_eth_txconf txconf = info.default_txconf;
	txconf.offloads = conf.txmode.offloads;
	rc = rte_eth_tx_queue_setup(id, 0, nb_txd, static_cast<unsigned>(socket),
				    &txconf);
	if (rc != 0)
		throw std::runtime_error(err("rte_eth_tx_queue_setup", id, rc));

	rc = rte_eth_dev_start(id);
	if (rc != 0)
		throw std::runtime_error(err("rte_eth_dev_start", id, rc));
	started_ = true;

	rc = rte_eth_promiscuous_enable(id);
	if (rc != 0)
		throw std::runtime_error(err("rte_eth_promiscuous_enable", id, rc));

	rc = rte_eth_macaddr_get(id, &mac_);
	if (rc != 0)
		throw std::runtime_error(err("rte_eth_macaddr_get", id, rc));
}

Port::~Port()
{
	if (started_) {
		rte_eth_dev_stop(id_);
		started_ = false;
	}
	rte_eth_dev_close(id_);
}

void
Port::wait_link_up(int timeout_s)
{
	for (int i = 0; i < timeout_s * 10; i++) {
		rte_eth_link link;
		std::memset(&link, 0, sizeof(link));

		const int rc = rte_eth_link_get_nowait(id_, &link);
		if (rc == 0 && link.link_status == RTE_ETH_LINK_UP) {
			speed_mbps_ = link.link_speed;
			return;
		}
		usleep(100000);
	}

	throw std::runtime_error("port " + std::to_string(id_) +
				 " link did not come up");
}

void
Port::hw_counters(PortHwCounters& out) const
{
	rte_eth_stats s;
	std::memset(&s, 0, sizeof(s));

	if (rte_eth_stats_get(id_, &s) != 0) {
		std::memset(&out, 0, sizeof(out));
		return;
	}

	out.opackets = s.opackets;
	out.obytes = s.obytes;
	out.ipackets = s.ipackets;
	out.ibytes = s.ibytes;
	out.imissed = s.imissed;
	out.ierrors = s.ierrors;
	out.oerrors = s.oerrors;
	out.rx_nombuf = s.rx_nombuf;
}

}  // namespace tgen
