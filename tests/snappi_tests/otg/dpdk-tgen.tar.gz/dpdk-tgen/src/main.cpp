// dpdk-tgen engine.
//
// Two modes over the same data plane:
//
//   default   one flow from the command line, run, print an acceptance
//             report and exit. This is stage 1a and needs nothing else.
//   --server  wait on a command socket and be driven by the Python control
//             process. This is stage 1b.

#include <arpa/inet.h>
#include <getopt.h>
#include <signal.h>
#include <unistd.h>

#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>

#include <rte_cycles.h>
#include <rte_eal.h>
#include <rte_ethdev.h>
#include <rte_lcore.h>
#include <rte_mbuf.h>

#include "cmdserver.hpp"
#include "port.hpp"
#include "shm.hpp"
#include "tgen.hpp"

namespace {

using namespace tgen;

constexpr std::uint32_t kMbufs = 16384;
constexpr std::uint16_t kDataRoom = 10240;

Engine* g_engine = nullptr;

void
on_signal(int sig)
{
	std::fprintf(stderr, "\nsignal %d, stopping\n", sig);
	if (g_engine != nullptr) {
		g_engine->tx_enabled.store(false, std::memory_order_relaxed);
		g_engine->force_quit.store(true, std::memory_order_relaxed);
	}
}

struct Options {
	std::uint16_t tx_port = 0;
	std::uint16_t rx_port = 1;
	std::uint16_t frame_size = 9000;
	std::uint64_t rate_pps = 0;
	double rate_percent = 0.0;
	std::uint32_t duration_s = 10;
	std::uint32_t interval_s = 1;
	std::string src_ip = "10.0.0.1";
	std::string dst_ip = "10.0.0.2";
	std::uint16_t src_l4 = 5001;
	std::uint16_t dst_l4 = 5002;
	bool have_src_mac = false;
	bool have_dst_mac = false;
	rte_ether_addr src_mac{};
	rte_ether_addr dst_mac{};
	std::string shm_path = "/dev/shm/dpdk-tgen-stats";
	bool server = false;
	std::string socket_path = "/var/run/dpdk-tgen.sock";
};

void
usage(const char* argv0)
{
	std::printf(
		"usage: %s <EAL args> -- [options]\n"
		"\n"
		"  --server            wait for commands instead of running once\n"
		"  --socket-path P     command socket (default /var/run/dpdk-tgen.sock)\n"
		"  --shm-path P        stats region (default /dev/shm/dpdk-tgen-stats)\n"
		"  --tx-port N         transmit port index (default 0)\n"
		"  --rx-port N         receive port index (default 1)\n"
		"  --frame-size N      ethernet frame bytes excluding FCS (default 9000, min %u)\n"
		"  --rate-pps N        packets per second (default: unthrottled)\n"
		"  --rate-percent F    percent of line rate, resolved from link speed\n"
		"  --duration N        seconds to transmit, 0 for until interrupted (default 10)\n"
		"  --stats-interval N  seconds between stats lines (default 1)\n"
		"  --src-mac A         default: transmit port address\n"
		"  --dst-mac A         default: receive port address (back to back)\n"
		"  --src-ip A          default 10.0.0.1\n"
		"  --dst-ip A          default 10.0.0.2\n"
		"  --src-port N        UDP source port (default 5001)\n"
		"  --dst-port N        UDP destination port (default 5002)\n"
		"  --help\n",
		argv0, kMinFrame);
}

bool
parse_args(int argc, char** argv, Options& o)
{
	static const option longopts[] = {
		{"tx-port", required_argument, nullptr, 1},
		{"rx-port", required_argument, nullptr, 2},
		{"frame-size", required_argument, nullptr, 3},
		{"rate-pps", required_argument, nullptr, 4},
		{"rate-percent", required_argument, nullptr, 5},
		{"duration", required_argument, nullptr, 6},
		{"stats-interval", required_argument, nullptr, 7},
		{"src-mac", required_argument, nullptr, 8},
		{"dst-mac", required_argument, nullptr, 9},
		{"src-ip", required_argument, nullptr, 10},
		{"dst-ip", required_argument, nullptr, 11},
		{"src-port", required_argument, nullptr, 12},
		{"dst-port", required_argument, nullptr, 13},
		{"shm-path", required_argument, nullptr, 14},
		{"server", no_argument, nullptr, 15},
		{"socket-path", required_argument, nullptr, 16},
		{"help", no_argument, nullptr, 'h'},
		{nullptr, 0, nullptr, 0},
	};

	int c;
	while ((c = getopt_long(argc, argv, "h", longopts, nullptr)) != -1) {
		switch (c) {
		case 1: o.tx_port = static_cast<std::uint16_t>(atoi(optarg)); break;
		case 2: o.rx_port = static_cast<std::uint16_t>(atoi(optarg)); break;
		case 3: o.frame_size = static_cast<std::uint16_t>(atoi(optarg)); break;
		case 4: o.rate_pps = strtoull(optarg, nullptr, 10); break;
		case 5: o.rate_percent = atof(optarg); break;
		case 6: o.duration_s = static_cast<std::uint32_t>(atoi(optarg)); break;
		case 7: o.interval_s = static_cast<std::uint32_t>(atoi(optarg)); break;
		case 8:
			if (rte_ether_unformat_addr(optarg, &o.src_mac) != 0) {
				std::fprintf(stderr, "bad --src-mac\n");
				return false;
			}
			o.have_src_mac = true;
			break;
		case 9:
			if (rte_ether_unformat_addr(optarg, &o.dst_mac) != 0) {
				std::fprintf(stderr, "bad --dst-mac\n");
				return false;
			}
			o.have_dst_mac = true;
			break;
		case 10: o.src_ip = optarg; break;
		case 11: o.dst_ip = optarg; break;
		case 12: o.src_l4 = static_cast<std::uint16_t>(atoi(optarg)); break;
		case 13: o.dst_l4 = static_cast<std::uint16_t>(atoi(optarg)); break;
		case 14: o.shm_path = optarg; break;
		case 15: o.server = true; break;
		case 16: o.socket_path = optarg; break;
		case 'h':
		default:
			usage(argv[0]);
			return false;
		}
	}

	if (o.frame_size < kMinFrame ||
	    o.frame_size > kDataRoom - RTE_PKTMBUF_HEADROOM) {
		std::fprintf(stderr, "--frame-size must be between %u and %u\n",
			     kMinFrame, kDataRoom - RTE_PKTMBUF_HEADROOM);
		return false;
	}
	if (o.tx_port == o.rx_port) {
		std::fprintf(stderr, "--tx-port and --rx-port must differ\n");
		return false;
	}
	if (o.interval_s == 0)
		o.interval_s = 1;

	return true;
}

std::uint32_t
parse_ipv4(const std::string& s)
{
	in_addr a{};
	if (inet_pton(AF_INET, s.c_str(), &a) != 1)
		throw std::runtime_error("bad IPv4 address: " + s);
	return rte_be_to_cpu_32(a.s_addr);
}

struct Totals {
	std::uint64_t tx_pkts = 0;
	std::uint64_t tx_bytes = 0;
	std::uint64_t tx_fail = 0;
	std::uint64_t rx_pkts = 0;
	std::uint64_t rx_bytes = 0;
	std::uint64_t rx_unmatched = 0;
	std::uint64_t alloc_fail = 0;
};

Totals
sum(const ShmRegion* shm, std::uint16_t flow_id)
{
	Totals t;
	for (std::uint16_t i = 0; i < kMaxLcores; i++) {
		const LcoreBlock& b = shm->lcore[i];
		t.tx_pkts += b.flow[flow_id].tx_pkts;
		t.tx_bytes += b.flow[flow_id].tx_bytes;
		t.tx_fail += b.flow[flow_id].tx_fail;
		t.rx_pkts += b.flow[flow_id].rx_pkts;
		t.rx_bytes += b.flow[flow_id].rx_bytes;
		t.rx_unmatched += b.rx_unmatched;
		t.alloc_fail += b.tx_alloc_fail;
	}
	return t;
}

// Wire bits include FCS, preamble and inter-frame gap so the figure is
// directly comparable to the nominal link rate.
double
wire_gbps(std::uint64_t pkts, std::uint16_t frame_size, double seconds)
{
	if (seconds <= 0.0)
		return 0.0;
	return static_cast<double>(pkts) * (frame_size + kWireOverhead) * 8.0 /
	       seconds / 1e9;
}

bool
check(const char* what, bool ok)
{
	std::printf("  [%s] %s\n", ok ? "PASS" : "FAIL", what);
	return ok;
}

void
refresh_hw(Engine& engine, const std::vector<Port*>& ports)
{
	for (Port* p : ports) {
		if (p == nullptr)
			continue;
		PortHwCounters c{};
		p->hw_counters(c);
		engine.shm->port[p->id()] = c;
	}
}

int
run_oneshot(Engine& engine, const Options& opt, const std::vector<Port*>& ports)
{
	engine.shm->header.start_tsc = rte_rdtsc();
	engine.shm->header.engine_state = kStateRunning;
	engine.tx_enabled.store(true, std::memory_order_relaxed);

	Totals prev;
	std::uint32_t elapsed = 0;
	const std::uint64_t hz = rte_get_tsc_hz();
	std::uint64_t prev_tsc = rte_rdtsc();

	while (!engine.force_quit.load(std::memory_order_relaxed)) {
		sleep(opt.interval_s);
		elapsed += opt.interval_s;

		const std::uint64_t now = rte_rdtsc();
		const double secs =
			static_cast<double>(now - prev_tsc) / static_cast<double>(hz);
		prev_tsc = now;

		const Totals cur = sum(engine.shm, 0);
		const std::uint64_t dtx = cur.tx_pkts - prev.tx_pkts;
		const std::uint64_t drx = cur.rx_pkts - prev.rx_pkts;
		prev = cur;

		std::printf("[%4us] tx %8.0f pps %6.2f Gbps | rx %8.0f pps %6.2f Gbps"
			    " | loss %" PRId64 "\n",
			    elapsed, dtx / secs, wire_gbps(dtx, opt.frame_size, secs),
			    drx / secs, wire_gbps(drx, opt.frame_size, secs),
			    static_cast<std::int64_t>(cur.tx_pkts - cur.rx_pkts));

		if (opt.duration_s != 0 && elapsed >= opt.duration_s)
			break;
	}

	// Stop transmitting, then let the last packets arrive before the
	// receive worker is torn down. Without this drain the final comparison
	// reports phantom loss.
	engine.tx_enabled.store(false, std::memory_order_relaxed);
	engine.shm->header.engine_state = kStateStopping;
	usleep(500000);
	engine.force_quit.store(true, std::memory_order_relaxed);
	rte_eal_mp_wait_lcore();

	refresh_hw(engine, ports);
	const PortHwCounters tx_hw = engine.shm->port[opt.tx_port];
	const PortHwCounters rx_hw = engine.shm->port[opt.rx_port];

	const Totals t = sum(engine.shm, 0);
	const std::int64_t lost = static_cast<std::int64_t>(t.tx_pkts) -
				  static_cast<std::int64_t>(t.rx_pkts);

	std::printf("\n=== summary ===\n");
	std::printf("flow 0   tx_pkts %" PRIu64 "  rx_pkts %" PRIu64
		    "  lost %" PRId64 " (%.6f%%)\n",
		    t.tx_pkts, t.rx_pkts, lost,
		    t.tx_pkts ? 100.0 * static_cast<double>(lost) /
					static_cast<double>(t.tx_pkts)
			      : 0.0);
	std::printf("         tx_bytes %" PRIu64 "  rx_bytes %" PRIu64 "\n",
		    t.tx_bytes, t.rx_bytes);
	std::printf("         tx_ring_full %" PRIu64 "  alloc_fail %" PRIu64
		    "  rx_unmatched %" PRIu64 "\n",
		    t.tx_fail, t.alloc_fail, t.rx_unmatched);
	std::printf("port %u  hw opackets %" PRIu64 "  oerrors %" PRIu64 "\n",
		    opt.tx_port, tx_hw.opackets, tx_hw.oerrors);
	std::printf("port %u  hw ipackets %" PRIu64 "  imissed %" PRIu64
		    "  ierrors %" PRIu64 "  rx_nombuf %" PRIu64 "\n",
		    opt.rx_port, rx_hw.ipackets, rx_hw.imissed, rx_hw.ierrors,
		    rx_hw.rx_nombuf);

	std::printf("\nchecks:\n");
	bool ok = true;
	ok &= check("received equals transmitted", t.rx_pkts == t.tx_pkts);
	ok &= check("no unmatched receives", t.rx_unmatched == 0);
	ok &= check("software tx equals hardware opackets", t.tx_pkts == tx_hw.opackets);
	ok &= check("software rx equals hardware ipackets", t.rx_pkts == rx_hw.ipackets);
	ok &= check("no hardware receive misses", rx_hw.imissed == 0);
	ok &= check("no hardware errors", rx_hw.ierrors == 0 && tx_hw.oerrors == 0);
	ok &= check("no mbuf allocation failures", t.alloc_fail == 0);

	std::printf("\n%s\n", ok ? "1a ACCEPTANCE: PASS" : "1a ACCEPTANCE: FAIL");
	return ok ? 0 : 1;
}

int
run_server(Engine& engine, EngineContext& ctx, const Options& opt)
{
	CommandServer server(ctx, opt.socket_path);

	engine.shm->header.engine_state = kStateReady;
	std::printf("ready: commands on %s, stats in %s\n",
		    opt.socket_path.c_str(), opt.shm_path.c_str());
	std::fflush(stdout);

	while (!engine.force_quit.load(std::memory_order_relaxed)) {
		if (!server.poll_once(100))
			break;

		// A configured duration expires here rather than in the
		// transmit worker, so the fast path carries no timekeeping
		// beyond its own pacing.
		if (ctx.stop_at_tsc != 0 && rte_rdtsc() >= ctx.stop_at_tsc) {
			engine.tx_enabled.store(false, std::memory_order_relaxed);
			ctx.stop_at_tsc = 0;
			engine.shm->header.engine_state = kStateStopping;
			usleep(200000);  // let the last packets land
			engine.shm->header.engine_state = kStateReady;
		}

		refresh_hw(engine, ctx.ports);
	}

	engine.tx_enabled.store(false, std::memory_order_relaxed);
	engine.force_quit.store(true, std::memory_order_relaxed);
	rte_eal_mp_wait_lcore();
	refresh_hw(engine, ctx.ports);

	std::printf("engine exiting\n");
	return 0;
}

}  // namespace

int
main(int argc, char** argv)
{
	int rc = rte_eal_init(argc, argv);
	if (rc < 0) {
		std::fprintf(stderr, "rte_eal_init failed\n");
		return 1;
	}
	argc -= rc;
	argv += rc;

	Options opt;
	if (!parse_args(argc, argv, opt)) {
		rte_eal_cleanup();
		return 1;
	}

	signal(SIGINT, on_signal);
	signal(SIGTERM, on_signal);

	int exit_code = 0;

	try {
		const std::uint16_t avail = rte_eth_dev_count_avail();
		if (avail < 2)
			throw std::runtime_error(
				"need 2 ports, found " + std::to_string(avail) +
				" (are both PCI addresses allowlisted with -a?)");

		Engine engine;
		g_engine = &engine;

		Shm shm(opt.shm_path);
		engine.shm = shm.region();

		engine.pool = rte_pktmbuf_pool_create(
			"tgen_pool", kMbufs, 256, 0, kDataRoom,
			static_cast<int>(rte_socket_id()));
		if (engine.pool == nullptr)
			throw std::runtime_error("rte_pktmbuf_pool_create failed: " +
						 std::string(rte_strerror(rte_errno)));

		Port port_a(opt.tx_port, engine.pool, opt.frame_size);
		Port port_b(opt.rx_port, engine.pool, opt.frame_size);
		port_a.wait_link_up(10);
		port_b.wait_link_up(10);

		std::vector<Port*> ports(
			static_cast<std::size_t>(std::max(port_a.id(), port_b.id())) + 1,
			nullptr);
		ports[port_a.id()] = &port_a;
		ports[port_b.id()] = &port_b;

		for (Port* p : ports) {
			if (p == nullptr)
				continue;
			std::printf("port %u link up %u Mbps, mac " RTE_ETHER_ADDR_PRT_FMT
				    "\n",
				    p->id(), p->speed_mbps(),
				    RTE_ETHER_ADDR_BYTES(&p->mac()));
		}

		ShmHeader& hdr = engine.shm->header;
		hdr.nb_lcores = RTE_MAX_LCORE;
		hdr.nb_ports = static_cast<std::uint32_t>(ports.size());
		hdr.tsc_hz = rte_get_tsc_hz();
		hdr.engine_state = kStateInit;

		const unsigned lcore_tx = rte_get_next_lcore(rte_get_main_lcore(), 1, 0);
		const unsigned lcore_rx = rte_get_next_lcore(lcore_tx, 1, 0);
		if (lcore_tx == RTE_MAX_LCORE || lcore_rx == RTE_MAX_LCORE)
			throw std::runtime_error(
				"need 2 worker lcores besides the main lcore, "
				"pass for example -l 2,3,4");

		WorkerArgs tx_args{&engine, opt.tx_port};
		WorkerArgs rx_args{&engine, opt.rx_port};
		rte_eal_remote_launch(rx_worker, &rx_args, lcore_rx);
		rte_eal_remote_launch(tx_worker, &tx_args, lcore_tx);

		std::printf("lcores: main %u, tx %u, rx %u\n",
			    rte_get_main_lcore(), lcore_tx, lcore_rx);

		EngineContext ctx;
		ctx.engine = &engine;
		ctx.ports = ports;

		if (opt.server) {
			exit_code = run_server(engine, ctx, opt);
		} else {
			FlowConfig& flow = engine.flows[0];
			flow.flow_id = 0;
			flow.tx_port = opt.tx_port;
			flow.rx_port = opt.rx_port;
			flow.frame_size = opt.frame_size;

			if (opt.rate_percent > 0.0) {
				const double line_pps =
					static_cast<double>(ports[opt.tx_port]->speed_mbps()) *
					1e6 / 8.0 / (opt.frame_size + kWireOverhead);
				flow.rate_pps = static_cast<std::uint64_t>(
					line_pps * opt.rate_percent / 100.0);
			} else {
				flow.rate_pps = opt.rate_pps;
			}

			// Back to back, the peer port's own address is the
			// correct destination, so neither MAC needs setting.
			const rte_ether_addr src_mac =
				opt.have_src_mac ? opt.src_mac : ports[opt.tx_port]->mac();
			const rte_ether_addr dst_mac =
				opt.have_dst_mac ? opt.dst_mac : ports[opt.rx_port]->mac();

			build_header(flow, src_mac, dst_mac, parse_ipv4(opt.src_ip),
				     parse_ipv4(opt.dst_ip), opt.src_l4, opt.dst_l4);

			engine.nb_flows.store(1, std::memory_order_relaxed);
			hdr.nb_flows = 1;

			std::printf("flow 0: port %u -> port %u, %u byte frames, ",
				    opt.tx_port, opt.rx_port, opt.frame_size);
			if (flow.rate_pps != 0)
				std::printf("%" PRIu64 " pps\n\n", flow.rate_pps);
			else
				std::printf("unthrottled\n\n");

			exit_code = run_oneshot(engine, opt, ports);
		}

		engine.shm->header.engine_state = kStateReady;
		g_engine = nullptr;
	} catch (const std::exception& e) {
		std::fprintf(stderr, "error: %s\n", e.what());
		exit_code = 1;
	}

	rte_eal_cleanup();
	return exit_code;
}
