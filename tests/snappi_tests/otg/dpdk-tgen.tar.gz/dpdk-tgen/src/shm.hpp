// Shared memory region holding the counters. Mapped from a file so the Python
// control process can attach to the same bytes in phase 1b without the data
// plane changing at all.

#pragma once

#include <string>

#include "tgen.hpp"

namespace tgen {

class Shm {
public:
	// Creates or truncates path, sizes it to the region, and maps it.
	explicit Shm(const std::string& path);
	~Shm();

	Shm(const Shm&) = delete;
	Shm& operator=(const Shm&) = delete;

	ShmRegion* region() { return region_; }

private:
	std::string path_;
	int fd_ = -1;
	ShmRegion* region_ = nullptr;
};

}  // namespace tgen
