# Example environment for tests/dut_flow.py on sonic-tb14.
# Copy and fill in the DUT MAC on Ethernet16, then: source this file && python3 tests/dut_flow.py ...

export TGEN_API=http://127.0.0.1:8443
export TGEN_TX_LOCATION=Card1/Port1
export TGEN_RX_LOCATION=Card1/Port2

DUT_FLOW_ARGS=(
  --src-mac 94:40:c9:88:2e:24
  --dst-mac a8:24:b8:8b:45:3d
  --src-ip 20.1.1.0
  --dst-ip 20.1.2.0
  --rate-pps 200000
  --seconds 60
)

# After the run, add DUT counters from:
#   show interface counters -i Ethernet16  (RX_OK)
#   show interface counters -i Ethernet24  (TX_OK)
# DUT_FLOW_ARGS+=( --dut-ingress-rx N --dut-egress-tx M --require-dut-counters )
